# mark-auto 程式品質與交易風險審查

<!-- CURRENT_STATUS_START -->

## 推論前清單檢查上限錯誤（2026-10-16）

第一次真研究在預留請求前失敗（無收據、未送出推論）。原因為推論前的模型清單檢查沿用 256 KiB 推論上限。PR #31 修正並追加第19個 producer profile。風險：研究 worker 只回傳例外類別，細碼不可見（pinned engine 來源，暫不改）；真推論仍未驗。

## 模型清單取得成功；推論待驗（2026-10-16）

模型清單失敗的真因已由固定階段分類觀測到：官方清單超過 256 KiB。PR #29（main `266f3bd6`）把清單上限改為 8 MiB 並追加第18個 producer profile；真實 App 已列出7個模型。剩餘風險：真推論、額度不足與授權失效處理未驗；Paper 診斷10秒與 smoke 40秒逾時在 CI 反覆出現，根因未修；安裝目錄舊 payload 累積。230/300（76.67%）不變。

## 登入成功；模型取得失敗階段未知（2026-10-16）

真實官方登入已成功（TLS 修復有效）。模型取得失敗被通用訊息遮蔽，PR #27（main `a758a5b4`）加入固定白名單階段分類，新預覽 desktop-preview-38797914196-1 核驗 PASS，但本機因程式執行中尚未更新。真因未知，需更新後再取一次模型以觀測階段；不猜修。推論、額度不足、授權失效處理仍未驗，M6 未過，230/300（76.67%）不變。Paper 診斷10秒逾時（112/120）再次出現，根因仍未修。

## OAuth 交換失敗根因：過期交叉簽署根憑證（2026-10-16）

本機 CurrentUser\CA 內過期的 `ISRG Root X2` 使 Python/OpenSSL TLS 驗證失敗（瀏覽器用 Windows 驗證器不受影響），導致交換階段 `transport_failure`。已以 ROOT-only 信任錨修復並追加第17個 producer profile，歷史16個身分不變。風險：`quantlab/downloads.py`、`market_providers.py`、`provider.py` 仍用預設 context；有效 code 的真回應仍未觀測；CI／Release／實機仍待驗。原230/300（76.67%）不變。

更新：PR #25 已合併為 main `ded354bd`，必要 CI 全通過（含各一次有證據保存的同SHA重跑：PR Quantlab desktop smoke 逾時、main Windows GUI fixture 未就緒，根因均未證明修復）；[預覽](https://github.com/yostar77612/mark-auto/releases/tag/desktop-preview-38783511431-2) 實際下載 bytes 與來源核驗 PASS，本機已備份後更新且資料保存；已安裝程式對官方 discovery／JWKS 探測 HTTP 200。真登入仍待 owner 一次操作，結果前不宣稱成功。

<!-- RESUME_DELIVERY_CHECKPOINT -->

## PR #24 已合併、預覽及實機更新PASS；真OAuth仍待驗（2026-10-15）

PR exact head `a740e429` 的完整 Quantlab 20 jobs 及 Windows security/build/TLS/lifecycle/recovery/provenance PASS；合併 main `9f4bcdb777b8f511daf7cfe43e5b2d8a25237ecb`／tree `bcdf96dc0771b394c1a6b714a2a2ad8f881f2425` 與已測相同。原 15 profiles 與所有執行函式不變，追加第16個精確來源身分。PR artifact 的87 tracked inputs、9 kit files、CRC及實際 installer hash 已驗，尚非 main Release。

整合後Quantlab `38736087836` attempt1的Windows3.12 Paper診斷原10秒只完成60/120 FULL commits後逾時，兩個aggregate嚴格拒絕。全部證據先保存，僅一次完全同main SHA attempt2重驗，全20 jobs PASS；Windows `38736087801` security/build/release全3 PASS，1846 tests＝1813 PASS／33既有skips／832.933秒。原失敗仍保留，未宣稱效能根因已修復，無source/test/workflow變更／降低期限工作量／mock替代／略過測試。

公開 [preview](https://github.com/yostar77612/mark-auto/releases/tag/desktop-preview-38736087801-1) setup39,420,084 bytes／SHA256 `5cf72a20a4749c32a66ae6b4988056bbfec3b597806632051226001437e240b7`已實際驗算；10下載assets/87來源inputs/9 kit files/CRC全部PASS。本機先備份408,205,162 bytes專屬安裝與資料，再有界更新；來源/SQLite/捷徑/既有AppData與workspace逐檔保存PASS，46.791秒、cleanup_verified=true，無UAC或全域修改。

原230/300（76.67%）、餘70/300（23.33%）不變；真OAuth原因及推論、clean Win10/Win11、DPI、合法完整行情、簽章與main保護仍未通過。現在只需owner一次官方登入，安全階段提示並非根因修復證據。詳細來源、CI連結、保存位置與接續條件見 [PROJECT_STATE](../agent/PROJECT_STATE.md) 的最新交付檢查點；下方保留歷史。

<!-- RESUME_DELIVERY_CHECKPOINT_END -->

## PR #24：追加 auth 來源身分，真實登入仍待驗（2026-10-15T19:49+08:00）

正式驗收維持 **230/300＝76.67%，剩餘 70/300＝23.33%**。D5／D7／D8／M2／M6／M7 原權重 10／10／10／20／10／10 不變；本次工程測試不增加分數，沒有獨立工程完成百分比。

修補前 head `1cd0fbe7` 的完整 CI 受兩項歷史 auth pins／current checkout 混用阻塞；兩項本機重新重現。修補在 `saved_candidate_pool.py` 只追加一個精確 LF／CRLF SIWC profile，保留原 15 profile 完整 hash、descriptor、result、manifest、dependency artifact 與選擇邏輯；新舊來源各自選回原身分，未知／混合／竄改拒絕。歷史測試不再把 current auth 誤當歷史 bytes，新增 5 項回歸固定原 15 hashes 與唯讀新舊結果。GitNexus 所示 admission／WFO 高影響由直接來源閱讀與必要完整 CI 覆蓋，不能以 graph 無變更代替測試。

直接 180 tests：178 PASS／2 既有平台 skips，42.360 秒；含原 13 token-format tests、來源 Gate、provider／UI 整合。Static/history 0 findings。另保留兩項本機 Win1314 symlink errors 與初次缺 Qt／錯誤模組 invocation，沒有提升權限或跳過測試；新 exact-head Windows CI、Quantlab、installer/TLS/lifecycle/recovery/provenance 尚 PENDING。審查完整來源與 artifact 且所有必要 Gate PASS 才能整合；最終來源／CI／公開 bytes 證據接續於 [PR #24](https://github.com/yostar77612/mark-auto/pull/24)，不為純狀態更新重建產品。

目前沒有可交付的新 installer；c736 舊版真登入仍失敗。官方文件已重新核對 direct scope、公用 Responses、`store:false`／`stream:true` 與參數限制；格式相容修正尚未證明為 owner 失敗真因。真 OAuth／推論、clean Win10／Win11、DPI、完整合法行情與簽章／main 保護仍未通過；只在新安裝檔 Gate 後請 owner 授權一次。完整資源限制、保全位置與下一步見 [PROJECT_STATE](../agent/PROJECT_STATE.md)。

### 以下為先前檢查點（保留原文，非目前待辦）

## PR #15 目前風險：UIA positive Gate 失敗（2026-10-12 17:47 UTC）

[Draft PR #15](https://github.com/yostar77612/mark-auto/pull/15)／head `82858f9a058d814e7d805f7a49621e8bb3343275` 尚不可合併或正式發布。正式驗收仍 **230/300＝76.67%，剩餘 70/300＝23.33%**，含原 Win11 條件；原 ID／權重／證據不改，工程完成率沒有獨立固定分母。

- **native PASS 與未驗證分開：** `70d56790` 的所有權 17 控制、1,665 PASS／33 skips、lifecycle／recovery／provenance 僅認證該來源；其 calibration FAIL／core job 取消仍保留。`099a4dae` [Quantlab 38284029532](https://github.com/yostar77612/mark-auto/actions/runs/38284029532) 18 jobs PASS、1,750 IDs 完整 core／research 分割及原 10／20／30／40 秒 Gate 通過，不等於最新候選或 clean-client 通過。
- **目前 UIA 失敗未歸因：** [Windows 38285371834](https://github.com/yostar77612/mark-auto/actions/runs/38285371834) 原 17 控制 PASS；owned fixture 僅 2 elements／0 required navigation，positive Gate FAIL，後續 foreign-window case 未執行。cleanup／零 owned descendants 另證 PASS，durable diagnostics 保留；build／完整 native／lifecycle／recovery 未執行，release SKIPPED。fixture-only WPF 替代方案已完成來源審查、待原生 Gate，不宣稱 root cause 修復或實際 Qt 導航已驗證。[同 head Quantlab](https://github.com/yostar77612/mark-auto/actions/runs/38285371807) 此檢查點已全 18 jobs SUCCESS。
- **host 與外部邊界：** 已核驗舊 `70d56790` kit，但 Win10 產品 NOT_RUN；RemoteSigned／ZoneId 3 阻擋 unsigned 腳本，兩支精確腳本的備份／解除下載標記仍待批准，未變更安全設定。MarkAuto-only 備份／隔離授權不涵蓋無關檔案、全域、admin 或其他電腦。已使用 host 最多 PARTIAL，不替代 clean Win10／Win11、DPI、真 owner OAuth／訂閱推論或完整合法分鐘資料。無新增 paid API／local AI／實盤授權。

main `f202c47b`／[公開 unsigned 0.2.2 Preview](https://github.com/yostar77612/mark-auto/releases/tag/desktop-preview-38199994183-1) 不變；完整同來源 Gate／artifact 審查後才能依授權正常合併，正式發布條件另列。詳見 [PROJECT_STATE](../agent/PROJECT_STATE.md)。以下 13:12 UTC 紀錄完整保留，工程／host 進度以本節為準。

## 目前範圍風險：原 300 分／Win11 恢復（2026-10-12 21:12:31 +08:00／13:12:31 UTC）

使用者明確恢復原 300 分正式標準與 Win11 驗證，取代先前暫緩。目前 230/300＝76.67%、尚餘 70/300＝23.33%；D8 10 點恢復為 EXTERNAL BLOCKED、非 PASS，D5／M7 原 Win11 條件恢復。舊 230/290 僅為歷史；原 ID／權重／狀態／失敗證據不變。

目前 Win10 實體主機已准許 MarkAuto-only 安裝／UI／lifecycle，須先影響核對、備份、隔離及必要專屬位置；只完成環境盤點，產品未測，已使用主機不得冒充 clean Win10。其他電腦、新 VM、系統元件、管理員或全域設定仍需明確授權；無可證明合法／已授權 Win11 實測環境前 D8 保持阻塞。

最新 f202c47b 的 [unsigned preview](https://github.com/yostar77612/mark-auto/releases/tag/desktop-preview-38199994183-1)／CI／Server native／公開 bytes 已核驗；正式 clean-client／DPI、行情權利與真 SIWC 等仍未完成。工程實作沒有另一固定全專案分母，另報未獨立量化，不以 CI PASS 宣稱 100%。本文件未實作另行進行的安裝測試所有權修補；細節以 [PROJECT_STATE](../agent/PROJECT_STATE.md) 為準。

<!-- CURRENT_STATUS_END -->

## 以下為本次恢復前的歷史狀態（保留原文）

舊 230/290、Win11 延後、唯讀／全面本機停止及舊來源待 CI／未發布說法按原時間解讀；目前範圍、權限及基線以上節為準。

<!-- PRE_RESTORATION_CURRENT_STATUS_START -->

## 目前範圍與風險：Win11 驗收延後（2026-10-12 07:07:46 +08:00／2026-10-11 23:07:46 UTC）

使用者最新指示：「我之後也不會在win11系統上使用 所以win11的實測可以先移調不計入」。Windows 11 實測因此列為 USER_DEFERRED_OUT_OF_CURRENT_SCOPE，不是 PASS，也未判定技術上不支援。D8 原 10 點只從本輪分母排除；D5／M7 共享條件的 Win11 執行同樣延後。原 ID／權重／BLOCKED／失敗證據保留。

目前 230/290＝79.31%，尚餘 60/290＝20.69%；歷史 230/300＝76.67% 不改。D5 10、D7 10、M2 20、M6 10、M7 10 仍未全部通過；clean Win10 安裝生命週期、完整流程、原 DPI／可用性／持久化、完整合法分鐘行情及真實官方 SIWC 授權／推論的實質門檻不變。Win11 延後不解除這些風險，Server／fixture 不替代 client 或真帳戶證據。

已發布基線為 main `3ef9a740f4523d50fda3bb36ad119aedcd015895`；[Quantlab 38169393007](https://github.com/yostar77612/mark-auto/actions/runs/38169393007) 全 14 jobs SUCCESS，[Windows 38169393012](https://github.com/yostar77612/mark-auto/actions/runs/38169393012) 全 3 jobs SUCCESS，[unsigned preview](https://github.com/yostar77612/mark-auto/releases/tag/desktop-preview-38169393012-1) 已發布。詳細 digest、scope overlay 與剩餘分項見 [PROJECT_STATE](../agent/PROJECT_STATE.md)／ACCEPTANCE.json。main 保護／受信任簽章仍未閉合，個人 PC／admin／UAC／VM STOP，券商 API 延後；未授權 live AI／實盤。這次只改文件，無新增實测或驗收分數。

<!-- PRE_RESTORATION_CURRENT_STATUS_END -->

## 以下為本次範圍變更前的歷史快照

下方原文及失敗證據完整保留，不代表目前平台範圍、進度或發布終態。

<!-- PRIOR_CURRENT_SNAPSHOT_START -->

## 已審查來源風險證據更新（2026-10-11 19:11 UTC）

來源 `3c721f79db6c0f938b9a0a9383e81a61b32c9b86`／tree `ba8ecb2dfbcd799c9a63cef4c25a4c38503ba893` 的 [Quantlab 38165405165](https://github.com/yostar77612/mark-auto/actions/runs/38165405165) 全 14 jobs PASS，兩個 Windows cores 的 40 項 WFO WAL／initialization／workspace tests 實際通過。[Windows installer 38165405175](https://github.com/yostar77612/mark-auto/actions/runs/38165405175) build/security 已 SUCCESS（原生 1,627＝1,594 PASS／33 skips，768.849 秒），80 source inputs、41 outer／8 nested entries、CRC／digest 及 5 個 actual frozen helper proofs／TLS／安裝生命週期已獨立核驗，PR release SKIPPED，尚非公開發布；後續整合／公開發布以 [PR #11](https://github.com/yostar77612/mark-auto/pull/11) 的 exact-source 證據為準，不能沿用舊 preview 為新候選背書。

新 WFO journal 使用 WAL/FULL，逐次 save／commit／export 保留；舊 DELETE DB 不遷移。patched SQLite ≥3.51.3／local-filesystem 是所有 WFO 入口的明示需求，舊 runtime／network 路徑拒絕；bundled Windows 3.54、WAL 前 durable workspace guard、guarded backup v2／restore rollback union 與初始化 crash 邊界已有原生測試。WFO crash／backup 是 real SQLite SOURCE tests；released EXE guard 使用 fixture sentinel，不能混稱完整 clean-client、真實 OAuth 或硬體斷電認證，也不能靜默繞過 guard。來源可查 `quantlab/walk_forward.py`、`quantlab/desktop_runtime.py`、`tests/test_workspace_wal_guard.py` 與對應 WFO 原生測試。

原始 helper 持有原 Job Object 並取得匹配停止 receipt 的狹義復原已實作；helper 同亡／重啟／缺證據必須 fail closed，禁止 AI 重送、預算重設或假設 PID 缺席等於停止。保存结果及非 AI 安全操作不應無條件鎖死。一般完整重啟、同使用者竄改認證與整體 rollback 不能由 ledger hash 宣稱安全。clean Win10／Win11、owner SIWC、完整行情權利／DPI、main 保護及受信任簽章仍分別待驗／受限；230/300 固定驗收與所有歷史失敗不變。個人 PC/admin/UAC/VM STOP。

## 原始 Job 停止證據復原候選（2026-10-11 14:28 UTC；提交前來源快照）

- **最後已發布基線不變：** [PR #9 最終證據](https://github.com/yostar77612/mark-auto/pull/9) 已確認合併 main `60da0e3b4f5c230f529a99e8ba5794fd2b232bfb`／tree `a04dddae25781b94d4759a13c77a36e319b4730c`；[Quantlab 38141626721](https://github.com/yostar77612/mark-auto/actions/runs/38141626721) 全 12 jobs SUCCESS，[Windows 38141626727](https://github.com/yostar77612/mark-auto/actions/runs/38141626727) build/security/release SUCCESS。Server 2022 原生 1,450＝1,417 PASS／33 skips，不能替代 clean Win10。[已核驗 unsigned preview](https://github.com/yostar77612/mark-auto/releases/tag/desktop-preview-38141626727-1) installer 39,355,463 bytes，SHA-256 `917d39c5d73bb70160b7e3771c5fb11d4297904119ac4e9a8fe85021b342a47e`。以下舊 PR #9 Draft／待 CI 字樣只屬保留歷史，不代表目前狀態；後續終態以對應 PR 證據為準，不為追逐文件 SHA 重建相同產品。
- **新候選 FOCUSED_TESTS_IN_PROGRESS：** `analysis_recovery.py` 原始 launch／stop ledger、`analysis_recovery_windows.py` helper、runtime／UI 衝突操作 guards 及 frozen hook 工作中；尚未新 exact-head CI、發布或取得 production／native Windows PASS。前次完成分支已刪除，預計重用 `agent/windows-release-validation` 名稱；新 PR 尚未建立。當前定向測試進行中，不列未完成的總數。
- **狹義能力界線：** 僅針對原 GUI 死亡而 helper 仍持有原 Job Object 並確認全部原 job 停止、提交匹配 stop receipt 後的明確本機 reconciliation；不得以 PID／Job 缺席或 journal completed 推定停止。helper 與 GUI 同亡、reboot 或缺 receipt 仍未知並限制衝突操作；不重送 AI、不退還／重設 consumed budget，不聲稱任意整機重啟復原。
- **可用性與可信界線：** incomplete／corrupt controls 對分析、來源變更、備份／還原等衝突操作 fail closed，不一律封鎖保存結果、比較與非 AI 回測；已有雲端 Qt 非 AI 可用性測試，但目前來源最終測試與實際 client 均未核驗。ledger hashes 是一致性檢查，不認證同使用者竄改或整體 rollback；ownership／registration／workspace／restore epoch／原 receipt Gate 不能省略。
- **14:46 UTC 最新原範圍／安全指令：** 保留原 Windows 10 與 Windows 11 驗收需求，除非使用者再次明確變更；目前兩者均 EXTERNAL BLOCKED，先前 Win11 取消指令僅保留為歷史。券商 API 仍 USER_DEFERRED；個人電腦所有 admin／UAC／VM 工作停止，TestLab 保留。實際 SIWC／OAuth、完整資料權利及 signing／protection 仍未閉合。原 ID／權重／300 分母與 230/300 歷史基線不變，復原工程不因此加點。
- **目前狀態分列（14:50 UTC）：** 實作＝原始 Job 復原候選與後續修正進行中；已驗證＝前述 PR #9 已發布基線，不能沿用為新候選 PASS；外部阻塞＝原 clean Win10／Win11、真實 OAuth 等；發布準備＝最終定向／獨立審查／新 exact-head native CI 尚待，未發布。
- **中間來源完整回歸保留：** tree `1f804e8861201512fc957df747f7cd82bf116edb` 的 full56372 終態 exit 1，1,548 項＝1,520 PASS／26 SKIP／2 FAIL，694.999 秒；兩項失敗均為 TEST_ONLY `_busy` adapter 不接受新增 `refresh_recovery` keyword。UI worker 修正 adapter，不更改 assertions；後續來源尚有獨立修補，最終 focused／native CI 仍待。此中間來源失敗不刪除、不追溯改 PASS，不代表已通過 production recovery。


### 以下為保留的舊來源快照與原始失敗；不得用於認證本候選

### PR #9 保留原生失敗，修正 READY_FOR_NATIVE_REVALIDATION（2026-10-11 12:27 UTC）

- Draft PR #9 head `2459ad62` 的 [Quantlab 38138317785](https://github.com/yostar77612/mark-auto/actions/runs/38138317785) 終態 FAIL。Linux 3.11：1,448 PASS／21 skips、425.277 秒；Linux 3.12：1,448 PASS／21 skips、447.131 秒；UI：1,448 PASS／16 skips、323.886 秒，7 個新增 Qt 測試實際 PASS。Windows research 3.11：243 PASS／6 skips、720.942 秒；3.12：243 PASS／6 skips、510.297 秒。各 job 分開列示，不相加。
- Windows core 3.12：1,205 PASS／27 skips／1 FAIL、398.629 秒，新 prototype helper-before-GUI cleanup 回報 Errno 5。core 3.11：1,205 PASS／27 skips／同一 FAIL＋1 ERROR、550.315 秒；既有 wrong-commit-count 測試於原 10 秒期限下耗時 10.124 秒且缺 returncode。舊失敗保留，不以未變更來源重跑洗掉，不能從原 log 指定唯一慢階段。
- test-only termination 修補已獨立審查，SHA-256 `5bb6ed2bec7ca515b7810ac318f5945b42fa90145add0b4a62a2b532bdef50ef`；要求 exact handle 在原 7 秒 cleanup 內 signal，1 個 deterministic PASS／3 Windows SKIP，真實 Windows 再驗仍待。`tools/diagnose_paper_replay.py` 狀態修補改報真正 reap 的 exit／未知 None，明確拒絕認證 timeout／error；原 120／FULL／delete-reopen／10 秒及 assertions 均保留。此為證據狀態修正，未證明效能已修復；診斷修補最終獨立審查 PASS，另有 4 個 targeted PASS（含真實 120／FULL／10 秒）；root 合併 `tests.test_paper_diagnostics`＋`tests.test_windows_recovery_feasibility` 23 項＝20 PASS／3 native Windows SKIP、5.096 秒（留存雲端 `quant-audit/ci-fix-focused.log`，非 repository 檔案）。修補 READY_FOR_NATIVE_REVALIDATION，待新 exact head CI；不宣稱效能修復。
- [Windows installer 38138317766](https://github.com/yostar77612/mark-auto/actions/runs/38138317766) 終態 FAILED：CPython 3.13.16／Qt 6.12 原生 1,448 項＝1,414 PASS／33 skips／1 FAIL、845.457 秒，同一 helper-before-GUI cleanup Errno 5，其餘 2 個 prototype cases PASS。7 個新增 Qt cases 實際 PASS，但 frozen／installer／lifecycle 尚未執行、release skipped，未產生新 installer；log 留存雲端 `quant-audit/ci-2459ad62/build.log`（非 repository 檔案）。PR #9 維持 Draft，main `f2eb4aaf` 與最後發布版不變；以下 READY_FOR_NATIVE_CI 為本 candidate 前次提交前狀態，現為修正／再驗待完成，沒有新增驗收點數或完整重啟復原。


## 最新發布基線與重啟復原界線（2026-10-11 11:49 UTC）

- **PR #8 已交付：** main `f2eb4aafba161ea89fd0457c20e21a06bea5918c`，tree `9566cffc6018650bd8133778f783f41e73509e2a`。[Quantlab 38134959143](https://github.com/yostar77612/mark-auto/actions/runs/38134959143) 全 12 jobs PASS；[Windows 38134959133](https://github.com/yostar77612/mark-auto/actions/runs/38134959133) build/security/release PASS，原生 1,425 項＝1,392 PASS／33 applicability skips。這是 Windows Server 2022 證據，不能替代 clean Win10。
- **已核验 unsigned preview：** [0.2.2 Release](https://github.com/yostar77612/mark-auto/releases/tag/desktop-preview-38134959133-1)，installer 39,355,004 bytes，SHA-256 `7aaf832869ba0d12a6f07a93acda7d9c36e1fa5fa34c6248d0942c012d391587`；77 個 source inputs 相符，公開 installer 已獨立下載核對。留存雲端診斷檔（非 repository 檔案）：`quant-audit/ci-f2eb4aaf/independent-installer-assessment.json`；可公開檢索證據見上述 Release／CI 與 [PR #8](https://github.com/yostar77612/mark-auto/pull/8)。TLS 僅 ephemeral loopback；安裝器中斷復原不等同分析 GUI 重啟復原。
- **新修補 READY_FOR_NATIVE_CI（未發布）：** `tests.test_desktop_analysis_discovery`＋`tests.test_reporting` 根整合 29 項＝22 PASS／7 native Qt SKIP，0.685 秒；雲端診斷 log `quant-audit/checkpoint-discovery-focused.log` 並非 repository 檔案。worker 另跑 7 項既有 strict-reader／recovery PASS，分開列示、不合併為同一 suite。變更僅 `desktop_ui.py`、`quantlab/reporting.py` 與新增 `tests/test_desktop_analysis_discovery.py`；research analysis／runtime／producer profiles 不變。初次 root＋獨立審查發現舊 checkpoint 選擇會遮蔽非同步 completed 結果，已改先選取返回的 analysis identity 再顯示並新增 native Qt 回歸，保留此初次診斷；最終獨立審查 PASS，獨立測試另為 22 PASS／7 Qt SKIP，strict worker adapter 字節不變；root 另跑完整 `tests.test_research_analysis` 31 PASS／0 skip，9.902 秒（留存雲端診斷 `quant-audit/checkpoint-analysis-regression.log`，非 repository 檔案），不與其他 suite 加總。原 `quality_gate.scan` 掃描遠端 255 檔 manifest＋2 個新測試共 257 檔，0 findings；本機 history scan NOT_RUN，待原生 CI。native Qt、Windows 實驗執行、exact-head CI 與發布仍待，不降低 Gate。journal-only 部分僅列出存在性 metadata，不讀取內容、不宣稱有效或 completed 結果；明示未核驗／unreconciled，不授予修復、重試、候選使用或重新推論權限。
- **完整 GUI 非正常重啟復原＝ENGINEERING BLOCKED：** 原 host 的程序樹停止證明不耐久；新 manager 的 proof 為空，不能用 PID 消失、QLockFile、completed journal 或逾時推定停止。這是工程缺口，不能歸因於 Win10 授權或要求使用者恢復本機管理員操作。固定發布來源：[proof 初始化](https://github.com/yostar77612/mark-auto/blob/f2eb4aafba161ea89fd0457c20e21a06bea5918c/quantlab/desktop_runtime.py#L940-L946)、[原 manager／registration admission](https://github.com/yostar77612/mark-auto/blob/f2eb4aafba161ea89fd0457c20e21a06bea5918c/quantlab/desktop_runtime.py#L1088-L1091)、[原 host tree join](https://github.com/yostar77612/mark-auto/blob/f2eb4aafba161ea89fd0457c20e21a06bea5918c/quantlab/desktop_runtime.py#L1252-L1253)。詳細評估與 probe 留存於雲端診斷檔 `quant-audit/restart-recovery-assessment/assessment.md`，非 repository 檔案，未聲稱 probe 已公開提交。Linux 真實 worker 曾在 supervisor abrupt exit 後仍存活；Windows restart 限制為來源分析，尚非真實平台重啟實驗。
- **未來固定復原 Gate：** 分離原／重啟 supervisor，含存活 descendants；驗證精確 ownership、PID reuse／copied或restored authority拒絕；真實 Windows Job Object 與 Linux process group；於 proof publication／reconciliation 中途終止；原 provider／receipt／request／exclusive lock 均不放寬，復原零 AI transport、零 budget reset、零重送。未實作或通過此 Gate，不聲稱完整復原。
- **範圍／安全不變：** Win11 USER_CANCELLED、券商 API USER_DEFERRED，皆非 PASS；所有個人電腦 admin／UAC／VM 操作停止，TestLab 保留。clean Win10、實際 SIWC／OAuth 及原其他外部限制維持。230/300 僅原固定範圍歷史參考，不增加點數或重算新分母。

### 以下保留先前來源與檢查點；其待 CI／未發布狀態不代表上述已發布 PR #8

### 10:39 UTC 新修補的定向驗證（未合併／未發布）

Paper replay 的 quarantined fill 不再消耗 pending plan/cursor，duplicate 需核對真實已保存成交；backtest 的 roll_close 被拒絕即停止，不切新合約或猜測補償下單；SIWC 串流所有已提供的 response ID 各自驗證，不能用另一欄遮蔽矛盾。根目錄整合定向 159/159 PASS（26.157 秒），獨立 review 及 11 項抽驗 PASS。新版本精確來源 profiles 去重後 78 項回歸 PASS（63.123 秒、0 skip），獨立 6 項 PASS；11 個已發布 literals 字節不改，只新增兩個 exact tuples。初次測試撰寫的 setup error 與重複 discovery 保留為診斷，不冒稱通過。新 exact-head 完整 CI 仍待執行，原持久化/效能 Gate 不變；這不是正式推論、clean client 或已發布來源的驗收。

## 本機停止與已發布來源邊界（2026-10-11 10:31 UTC）

- PR #7 的分析 projection 復原、時段邊界及 worker cleanup 已在 main `958df322` 通過 exact-head Windows/Linux CI 並發布預覽版；後文提交前的「待 CI」是歷史快照。新缺陷與新修補另行提供來源限定的測試，不沿用舊 PASS。
- Hyper-V 是使用者 08:44 UTC 明確批准後啟用，原狀態 Disabled；官方 NoRestart 操作 exit 3010。使用者自行重開機後已確認管理服務與模組，但最後管理員唯讀查詢追蹤失效、結果缺失，root cause 未確認。launch checkpoint 太晚與 finally 寫入無備援是證據缺口，不能據此推測程序歸屬、強殺或重試 UAC。
- 最新指令已停止所有個人主機管理員/VM排查；既有 TestLab 保留。需要此類權限的項目一律 EXTERNAL BLOCKED。沒有 Windows 客體授權，不把 host 啟用當成 VM license；沒有 clean Win10 實測，不以 Server CI 替代。
- 使用者已取消 Win11 驗收、暫緩券商 API；不是 PASS 或取得授權。仍禁止本機 AI、paid API/credits fallback、真實下單及未授權憑證讀取。原固定 230/300 僅為歷史分母基線，不因範圍縮減自動提升。
- 具體新風險與驗證結果由本次工程修補段落補充；完整來源、限制與操作證據索引見 PROJECT_STATE。

### 以下為保留的前次風險快照

## 雲端缺陷修復與隔離限制（2026-10-11）

1. 分析匯出 crash boundary：`quantlab/research_analysis.py` 的 `_save` 先 commit SQLite 再 replace JSON；真實子程序退出可留下 completed journal／running export。修復限定 `reconcile_analysis`，校驗原始控制帳本及 request／response，普通讀取不放寬。`desktop_ui.py` 明確復原分支不再提前被嚴格 projection 讀取卡住。新測試含 process death、缺少 export、竄改、原 provider、exclusive lock、禁止重送。
2. K 線 defensive validation：`quantlab/chart_data.py:aggregate_bars` 拒絕同契約／交易日／時段的矛盾 resolved bounds，保留獨立時段與縮短結算時段。`tests/test_chart_data.py` 有反例與正常界線測試；未證明正常官方匯入已產生壞資料。
3. Sandbox 維持 BLOCKED：官方 [.wsb 配置](https://learn.microsoft.com/en-us/windows/security/application-security/application-isolation/windows-sandbox/windows-sandbox-configure-using-wsb-file) 支援 LogonCommand 與受限 mapping；[shutdown](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/shutdown) 未承諾 host Sandbox teardown；[CloseMainWindow](https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.process.closemainwindow) 只保證發送關閉請求。沒有舊 client 可驗證的20分鐘專屬停止方案，不啟動本機、不以全域 kill 替代。
4. 整個 GUI／host 重啟仍缺可重建的 analysis 子程序停止證據與 journal-only 保存項目入口；本修補只覆蓋原 host 存活的 worker 中斷，不把直接 adapter 測試冒充 full-host restart。既有 single-instance／WFO owner 機制不足以證明舊子樹已終止；保持 BLOCKED，不放寬原停止證明或以新 reader 冒充原 owner。
5. 新增 worker cleanup 防護：`quantlab/research.py:_run_bounded` 原本在固定 cleanup joins 後無條件 close 尚存活 process；可用 delayed-reap double 重現 ValueError。新實作只花費原 deadline 剩餘時間，未確認停止即終止整個研究工作，不再繼續評估或歸還額度。此條件缺陷與第一次WFO全套失敗的因果尚未證實，不能刪除原失敗紀錄。
6. 第一版cleanup修補在原生Linux完整CI暴露zero-join回歸；應恢復原本terminate0.2秒＋kill0.2秒有界回收餘裕，與evaluation deadline分開，不能擴大推論／評估期限或忽略no-orphan測試。對應失敗與修正見PROJECT_STATE 02:07檢查點。
7. 以上新來源仍須完整測試與 exact-head CI；舊來源 PASS 不自動繼承。進度及可恢復入口見 [PROJECT_STATE](../agent/PROJECT_STATE.md)。

### 前一輪交付證據（保留）

## 目前交付對帳（2026-10-10 23:42 UTC）

0.2.2 unsigned preview 已從產品來源 `9d35c7d7` 發布；exact-main Quantlab 12 jobs、Windows native／frozen TLS／安裝升級復原與公開下載驗證均 PASS。M4 依原 §19 條件取得 20 點，現行 **230/300＝76.67%，剩餘23.33%**；其他固定權重與未通過項目不變。

詳細證據、下載、M4 判定與剩餘 D5／D7／D8／M2／M6／M7 分界統一見 [PROJECT_STATE](../agent/PROJECT_STATE.md) 與 ACCEPTANCE.json 的 current_snapshot。乾淨 Win10／Win11、真實 ChatGPT 訂閱授權／推論及完整市場分鐘資料權限仍未閉合；不以 Server／mock 冒充。此段記錄前一輪文件對帳；本輪修補與 Gate 狀態以上方新檢查點為準。
<!-- PRIOR_CURRENT_SNAPSHOT_END -->

## 以下為保留的歷史契約、決策與檢查點

截至本次對帳以前的210/300、M4 PARTIAL、IMPLEMENTATION_PENDING、失敗／取消／尚未發布等文字保留其原時間與來源；不代表目前終態。原需求、未解除安全底線及非本次明示更新的gate仍有效；歷史失敗不刪除、不追溯改為PASS。

<!-- HISTORICAL_STATUS_START -->
## 22:42修補後風險增量

最新來源／CI／本機證據與AUTO、FAILED、PASS、BLOCKED分界見[PROJECT_STATE最新檢查點](../agent/PROJECT_STATE.md)。目前正式發布仍被否決；以下只更新本輪新增證據，後文保留原歷史。

1. **FAILED／待原生重驗：** Win311完整smoke原40秒超時；Windows pipe reader在EOF前不提供partial output，二次cleanup timeout令診斷消失已可重現。修補只保留bounded白名單輸出，仍要求EOF、完整worker清理與原deadline；原逾時原因未被此修補證明。
2. **已修實作、待frozen Gate：** TLS檢查誤把OpenSSL3.5.9的CPython tuple當作前三碼semver。依[CPython v3.13.16 _ssl.c](https://github.com/python/cpython/blob/v3.13.16/Modules/_ssl.c)改驗精確五整數`(3,5,0,9,0)`，不更改DLL hash／size／位置、憑證驗證、TLS版本或cleanup。舊native failed report保留，不能推論沒有其他前置風險。
3. **已修UI一致性：** 超限參數不再造成畫面新值／舊曲線；新資料讓既有設定超限時，保留新candles並明示無法計算。只捕捉typed resource error，普通ValueError不掩蓋；兩個指標可逐一修復。
4. **量測支持的最小CPU改善：** canonical scalar快路徑保留所有驗證／bytes／歷史identity／COMMIT數；沒有journal mode、batch commit、同步或門檻變更。Linux單次29.66%差異不作Windows效能承諾。
5. **外部權利仍未閉合：** [官方Win11 Evaluation](https://www.microsoft.com/en-us/evalcenter/evaluate-windows-11-enterprise)所附EnterpriseEval條款SHA256 `6b5d4b32236a921bacdefe19852ec0699ca2eacd72d4e57f50a2de06ede21c8e` 的virtual-device及remote-only條款未明確解決hosted unattended CI；單純owner接受不等於取得未確立的hosting權利。KVM測試成功只移除基本執行能力疑慮。main保護在22:25仍未啟用；不改用未授權憑證繞過Administration限制。

## 當前整合狀態與最後已驗證基線（2026-10-10 12:14 UTC）

### 11:16 使用者更正：官方訂閱為必要 AI 路徑（取代先前選路）

官方 **Sign in with ChatGPT（SIWC）訂閱整合為必要需求**，第一階段已root套用：AI策略中心單一登入入口沿用既有官方PKCE/OIDC／受管worker，補齊帳戶／模型顯示、明示included-only確認及取消／關閉保護。本機模型UI、設定、runtime、下載器、打包與舊CI推論要求已移除；paid API／自訂endpoint入口亦關閉，無credits fallback；獨立TLS證據與歷史producer／研究紀錄保留。此更正只替換AI選路，不降低其他驗收；M4／M6仍PARTIAL、210/300＝70%，原研究隔離、耐久、工作量／deadline、安全、安裝及clean-client gates不變。

included-only確認與ChatGPT Settings > Usage指引已實作，仍是使用者自述，不是server credits設定查證或金額上限保證。官方能力邊界見[Help Center](https://help.openai.com/en/articles/20001542-using-your-chatgpt-plan-in-other-apps-and-sites)及IMPLEMENTATION_CONTRACTS同日更正。實際OAuth grant／模型呼叫仍NOT_RUN、EXTERNAL_BLOCKED，須owner授權；mock不代替此證據。

**第一階段來源／回歸：** full來源index tree `96ceacdf62224f39522bdccdbbd2b97d0e37cd06`，246個來源hash於終態核對不變（`quant-audit/subscription-phase1-source.json`／`subscription-phase1-source-verification.json`）。 1292項＝1271 PASS／20 skips／1 ERROR、1250.240秒、exit1；唯一ERROR為restart test仍引用已移除的`ai_opt_in`。20 skips為15個platform／PowerShell及5個此環境未裝Streamlit的optional UI tests，CI UI仍安裝它。原FAIL log保留於`quant-audit/subscription-phase1-full.log`。終態後才套用精確producer profile及test-only consent修補，root delta19項全PASS、0 skip、16.203秒、exit0（完整market14項＋profile5項；`quant-audit/subscription-phase1-root-delta.log`）。未重跑full，不追溯改寫FAIL。 獨立組合273 PASS／1 PowerShell skip、登入面板127 PASS、host43 PASS、精確producer profile8 PASS各按來源記錄，不相加。這是本機功能證據；實際環境Python3.12.14／SQLite3.53.1／Qt6.12.0，私有3.54載入probe被正確拒絕，未改產品runtime或CI的3.54要求。新native／frozen TLS／lifecycle及clean Win10／11仍NOT_RUN，未merge／未發布。按需策略評論／比較另列第二階段證據，不追溯算入此第一階段full。

**第二階段按需評論／比較亦已root套用。** 基於第一階段checkpoint `695c25c5006e1fe04fb49ade50288f759a963546`／tree `e10b49af26629ca2e6f323c82b966c737cef4352`，加入本機重新計算的training／validation、SMA／RSI／MACD證據預覽及明示同意後的單次官方訂閱分析；排除holdout／OOS，獨立耐久receipt、精確快取與offline重開不重打模型，取消／死亡先join原worker再對帳。AI文字為未受信解讀，數值按candidate／split由本機證據顯示，不覆寫策略、排名或下單。新增ledger亦納入first-use host guard；兩代精確producer profiles與歷史identities保留。

root backend **141 PASS／29.688秒**；host／runtime／packaging等 **152項＝151 PASS／1 PowerShell skip、78.542秒**，static／history 0 findings、diff check PASS。證據為`quant-audit/subscription-phase2-root-backend.log`、`subscription-phase2-root-host.log`及`subscription-phase2-docs/source-inventory.json`；isolated 1440×1000／1366×768視覺檢查僅synthetic fixture。沒有最終來源whole-suite／新native／實際grant PASS；待同一PR合併更新後的exact-head CI，不是已merge main或Release，也不改70%。

### 更正前來源與歷史證據（保留原結果，不認證第一階段SIWC-only）

恢復來源`f57ac5f39d86187945f9891b5cb7a16f5c674044`與未推送`d81ecb55`同tree `48ad5a1b6f8a813f2069b344c0629d48a3f090a6`；下列17db及其後更正前結果保留全部失敗，不追溯改寫。

**最後受測來源與後續root delta分開。** remote `17db263a87f4df39a82bfa9b80d7694afcf28879`／local `1673d676a507373720a9f83485046f588a22f143`為同tree `27a571aebcf21b1842d584127f0814e1abcce7e1`。Quantlab9 PASS／Win312 research CANCELLED；Windows build／Qt gate PASS但AI model_download FAIL，未進inference／lifecycle。其後exact-host／typed診斷／TLS／storage診斷／KVM修補已有本機full／focused證據，依來源分列，新native仍NOT_RUN。

- **公開下載仍只有0.2.1 unsigned preview。** [已核驗安裝檔與證據](https://github.com/yostar77612/mark-auto/releases/tag/desktop-preview-38016622951-1)，release main `2ed1e3e5fa8f6140e7305858e59a58555dcbc3e8`；PR5已合併main94aca467，但候選0.2.2／PR6仍Draft、未合併／未發布。
- **最新Quantlab38045449459終態：9 PASS／Win312 research CANCELLED。** UI1311項＝1298 PASS／13 skips、435.974秒；Linux311／312各1311項＝1293 PASS／18 skips、407.321／285.459秒；Windows311／312 core各1084項＝1067 PASS／17 skips、345.736／577.560秒。Win311 research227項＝223 PASS／4 skips、653.687秒；Win312於原15分鐘cap完成208項＝204 PASS／4 skips，第209項在`db.commit()`被中斷、18項未開始。storage診斷已套用、native量測待，沒有已修好或放寬cap的結論；e68取消與Linux312 observer原cause未知紀錄保留。
- **最新Windows38045449411已FAIL；建置成功不等於AI或安裝通過。** Installer環境Windows Server2022／CPython3.13.16／Qt6.12.0原生1311項＝1290 PASS／21 skips、765.646秒，build／Qt payload gate PASS。model_download於1.031秒失敗、category=`local_ai_network`、child exit1、無numeric HTTP status、非timeout、cleanup=true；0 model calls，frozen inference／install／lifecycle NOT_RUN。此category不能推論DNS、TLS、HTTP狀態或服務中斷；後續exact-host發現與原生歸因分界見下。Quantlab Windows cores為Server2025，兩種Server證據均不取代clean client。
- **實際17db263a installer靜態payload已獨立核驗。** artifact11667554811 ZIP 77,720,491 bytes／SHA256 `97bfa4f2a0660730f44f6c14581bc2084e43984de0ace5c50a6db2ca01c6a49b`，6 members，download hash／CRC PASS；0.2.2 installer 39,383,283 bytes／SHA256 `c2efa3f64424eaf24e6acec699bc1e3579927669d97dc52a36ad81046f398b58`。119個PE／982 payload entries證明原7項精確移除、無新增PE，retained DLL/PYD hashes全不變，依賴不引用已移除檔；Python3.5.9、qwindows／Schannel／cert backend與5份Qt notices均核對。這關閉該產物的靜態排除／notice-integrity證据，尚不認證loaded TLS、frozen HTTPS、IME、完整legal clearance、source-release交付或client。證據：`quant-audit/ci-17db263a/terminal-assessment.md`；app EXE hash是`7b383ca4…66b688aa`，非installer hash。未merge／未Release。
- **下載相容性缺口已證明並窄修，原生歸因仍待。** 固定model URL的TLS-verified HEAD為Hugging Face302→`us.aws.cdn.hf.co`200，Content-Length 1,117,320,736、linkedETag符合model SHA，0 body bytes；官方metadata列出此exact host，舊allowlist確實拒絕。只新增此host及有限typed network-cause診斷，TLS／size／hash／no-auth／proxy限制不變。17db失敗artifact未記rejected host，對該次失敗的歸因仍是inference。root combined151 PASS／2.367秒（`quant-audit/followon-integrated-targeted-20261010.log`）；其中TLS包含真owned-loopback HTTPS及憑證拒絕測試，Windows DLL載入證據仍mock。六檔synthetic storage診斷已套用，獨立CI job已實作、native量測未跑；product storage／COMMIT／原cap不變，未宣稱效能修復。HEAD與官方來源證據：`quant-audit/ci-17db263a/model-head-metadata.json`、`model-cdn-official-provenance.json`。
- **最新root full與其後diagnostic-only delta分開。** Linux1372項＝1357 PASS／15既有skips、291.628秒、exit0（`quant-audit/followon-root-full-20261010.log`），`followon-root-source-20261010.json`的219個pre-run hashes於完成後核對不變。其後才套用exclusive mkstemp report修補／3 regressions及獨立Windows3.12 storage job／7 offline contracts，故不算入該full來源。final focused初次70項＝68 PASS／1 skip／1 import error（錯拼module、2.440秒）保留；只改命令後78項＝77 PASS／1既有PowerShell skip、2.962秒、exit0（`quant-audit/followon-final-delta-corrected-20261010.log`），static／history0 findings、diff check PASS。未重跑full；新native仍NOT_RUN。storage job已實作，180秒量測／6分鐘job且保存INCOMPLETE；product storage mode／原COMMIT／原gates不變，量測COMPLETE也不等於產品驗收。
- **後續root測試與KVM證據分界。** TLS5檔focused70 PASS／0.299秒、quality boundary2檔14 PASS／0.027秒，KVM C／test／job3檔combined69 PASS／0.952秒，TLS含真owned-loopback HTTPS、Windows DLL證據則mock；quality／KVM為contract／mock，沒有Windows loaded TLS或VM執行。既有1311項root全套只屬17db263a前的來源。實際read-only KVM API12 query已成功（USER_MEMORY=1、IRQCHIP=1、recommended vCPUs=4、max=4096），artifact11667623060 SHA256 `d605336efdef16003e0d17e8133666f0952044642d8abd4dc0d14248a2eb6f40`；未create VM／run guest。新固定自撰payload execution self-test尚未原生執行，不涉及Windows OS映像。
- **歷史e68b3301／Quantlab38042425646：8 PASS／1 Linux312 FAIL／1 Win311 research CANCELLED。** Windows311／312 core各1029項＝1014 PASS／15 skips、406.239／339.883秒；UI1256項＝1243 PASS／13 skips、290.850秒；Linux3111256項＝1238 PASS／18 skips、426.842秒。Linux3121256項＝1237 PASS／18 skips／1 failure、417.872秒，為test-only process observer的cleanup=false；另已真實觀測Linux X dead state並修補X/x契約，但原CI未留process-state artifact，exact cause仍NOT_PROVEN。Win312 research227項＝223 PASS／4 skips、764.237秒；Win311在原15分鐘cap前完成222項＝218 PASS／4 skips，第223項被中斷、4項未開始，不記整套PASS。
- **歷史e68b3301／installer38042425591已FAIL，但已完成native全套與建置。** 原生1256項＝1237 PASS／19 skips、832.716秒，PyInstaller與兩個installer編譯PASS；AI download child於0.616秒exit1、非timeout、cleanup=true，未進frozen phase／0 model calls，其後install／lifecycle skipped。artifact11666369640 ZIP 83,451,533 bytes／SHA256 `b62c4e04edd9a3483f41f9a6d3701b83f7e6d8d8c320c4b04841af47e66c1d31`已下載核hash／CRC，5 members；0.2.2 installer 42,248,905 bytes／SHA256 `f7512490e8a7f5c07f456c7919ceb3b4e9db09f01325a172ca73127c75a8fd7a`，未發布。controller的`7600d5e8…672aaf6`是frozen app EXE hash，不能稱installer hash。證據：`quant-audit/ci-e68b3301/`。
- **歷史17db263a前整合的本機證據分開記錄。** WFO single-normalization保留相同hash bytes、全部原COMMIT與SQLite語義；當次root全套1263項＝1248 PASS／15 skips、290.403秒，source manifest `quant-audit/wfo-single-normalization-root-source-20261010.json`固定該次來源，不認證其後host／observer／Qt delta。其後Linux observer focused31 PASS／66.977秒；AI child失敗證據保留修補focused107 PASS／1.293秒，只修parent讀取／去敏順序，底層download cause仍未知。KVM opt-in query程式43 PASS＋partition9 PASS，但無實際sudo／KVM query；錯拼test module的44項／1 import error原log保留。所有重疊集合不相加，原300／660／10／120／135秒、15／35分鐘cap與單次嘗試不變。
- **歷史e68b3301 native風險與修補證據（後續17db靜態核驗如上）。** e68b3301實際126個PE的audit確認Qt另名`-x64` OpenSSL3.5.5，涉及[官方2026-09-29公告](https://openssl-library.org/news/secadv/20260929.txt)的CVE-2026-35189（TLS記憶體DoS）與CVE-2026-84782（DTLS）。Python `_ssl`／`_hashlib`使用不同basename的3.5.9；未找到app QtNetwork／QSsl呼叫，不宣稱Python HTTPS受此漏洞影響或已遭利用。root已套用精確移除qopensslbackend／3.5.5 pair與unused VirtualKeyboard／PDF的打包規則，保留Python3.5.9、qwindows、Schannel／cert backend，補完整GPL／LGPL與固定native notices／source links。新frozen payload未建置，不能宣稱已移除、已完成授權交付或pip-audit PASS等於native安全。Qt root初次65項＝63 PASS／1 failure／1 skip、0.757秒，是6個新build inputs尚未Git追蹤的guard；僅stage後原樣重驗65項＝64 PASS／1 PowerShell skip、0.780秒（`quant-audit/qt-packaging-root-tracked-20261010.log`），未改test／product來消除該失敗。獨立126-PE審查無blocker、static／history0 findings；最後整合root Linux全套1311項＝1296 PASS／15 applicability skips、288.641秒、exit0（`quant-audit/integrated-root-full-20261010.log`）；`quant-audit/integrated-root-source-20261010.json`所列來源hash已核對一致。這是Python3.12.14／SQLite3.53.1／Qt6.12.0的完整本機證據，新exact-head native CI仍NOT_RUN，不認證新Windows frozen payload或clean client。
- **歷史0088b505／Quantlab38032142094為9/10 PASS、整體FAIL。** Windows3.11 core806項＝790 PASS／15 skips／1 failure、433.599秒，唯一失敗仍是原960-bar Paper30秒。Windows3.12 core806項＝791 PASS／15 skips、339.431秒；UI1026項＝1013 PASS／13 skips、366.894秒；其他Linux／research／security通過。窄Linux ESRCH與Windows nested cleanup已有此來源驗證，不能冒稱新WAL／runtime／AI整合已通過。
- **歷史0088b505／Server38032142096 build／security及安裝流程PASS。** Server2022完整1026項＝1007 PASS／19 skips、808.047秒，該profile原Paper30秒／SystemExit40秒、frozen/history/WFO、真0.2.1升級／中斷恢復／移除保存通過；PR release skipped。實際候選artifact11663227244、PR merge703686e2、60個source inputs及EXE／kit／ZIP hashes已驗證，與0088b505同tree；這不是Release，也不能抵銷Windows311失敗或替代clean client。
- **歷史16974db3／Quantlab38040818017已終態：7 PASS／2 Windows core FAIL／1 Windows311 research CANCELLED。** Windows311 core1023項＝993 PASS／15 skips／7 failures／8 errors、546.573秒；Windows312 core1023項＝994 PASS／15 skips／6 failures／8 errors、399.402秒。UI1250項＝1237 PASS／13 skips、331.067秒；Linux311／312各1250項＝1232 PASS／18 skips、422.830／421.385秒；Windows312 research227項＝223 PASS／4 skips、636.478秒。Windows311 research達原15分鐘累計job上限，被取消時stack在WFO `_save_state` 的 `db.commit()`，數秒前測試仍在推進；不據此宣稱單一commit死鎖或任意加時。
- **歷史16974db3／installer38040817985在freeze前FAIL，沒有新installer或frozen AI呼叫。** 完整1250項＝1217 PASS／19 skips／6 failures／8 errors、874.196秒，與Windows312 core共14個相容性反例；Windows311 core另有一個terminal-cleanup測試失敗。build未進入freeze／實際單次AI／安裝驗證，這些保持NOT_RUN；不能沿用0088b505舊artifact的PASS。原生日誌與終態證據保留於`quant-audit/ci-16974db3/`。
- **歷史16974db3後的11檔相容性修補與failure-only WFO timing診斷已root套用。** Linux Python3.12.14／SQLite3.53.1／Qt6.12.0整合focused183項全PASS、0 skip、51.275秒（`quant-audit/windows-repair-integrated-focused-20261010.log`），static／完整可達history為0 findings，diff check PASS。這是修補後focused，沒有第二次root完整全套或新native PASS；WFO尚未做效能優化，原30／40／10秒、15／35分鐘job及所有驗收門檻不變，接續同PR新exact-head CI。
- **先前本機證據與負面結果按來源保留。** pre-AI root完整1096項＝1081 PASS／15 applicability skips、291.408秒，log `quant-audit/pre-ai-wal-integrated-full-20261010.log`與source manifest `quant-audit/pre-ai-wal-integrated-source-20261010.json`固定該次來源。其後本機AI focused153項＝152 PASS／1 skip、5.866秒；自動備份初次focused21項全PASS、0.966秒；offline-drive設定恢復修補後23項全PASS、0.962秒。focused logs見`local-ai-integrated-focused-20261010.log`、`automatic-backup-integrated-20261010.log`及`automatic-backup-integrated-final-20261010.log`。該次root venv實測為Linux Python3.12.14／SQLite3.53.1／Qt6.12.0，見`quant-audit/integrated-final-source-20261010.json`；早先手記Qt版本不作獨立量測證據。最終combined suite本次FAIL：1243項＝1225 PASS／15 skips／2 failures／1 error、300.720秒（`quant-audit/integrated-final-full-20261010.log`）。三項均為saved-candidate producer來源綁定未涵蓋provider hook變更後的source hash；現有fail-closed防線正確拒絕未匹配來源。兩個新的literal 0_2_2 transport-verifier profiles已獨立審查並root套用；原三個literal profiles與historical exact-hash測試未改，只將三個真正current-generated identity assertions移至新profile，tamper／mixed-source拒絕保留。修補後root focused150／150 PASS、0 skip、30.760秒（`quant-audit/provenance-integrated-focused-20261010.log`）；隔離54與138項PASS為重疊範圍，不相加。本次1243項FAIL保留，沒有第二次root完整重跑；其後16974db3原生終態另列於上方；不追溯改寫本次1243項FAIL。另`/usr/bin/python3`私有SQLite3.54.0載入probe及Paper111項＝110 PASS／1 skip、5.172秒屬獨立Linux範圍，見`/tmp/markauto-sqlite354-verified-setup.log`、`/tmp/sqlite354-paper-tests.log`。各集合不相加、不互相認證；目前root全套不是3.54或Windows證據。
- **歷史AI選路（11:16已被使用者更正取代，不再是目前交付要求）。** 可選llama.cpp／Qwen2.5-1.5B路徑使用官方固定hash runtime／model／support DLL來源；無付費fallback，official API預設off。localAI licenses與三個Microsoft DLL來源通知已補入packaging；實際新payload bytes／notices已靜態核驗；Microsoft downstream protective-terms充分性仍未定，未有demonstrated breach，也沒有強制付費license／新EULA／collector的依據，不自行增加這些驗收gate。17db263a supervisor的model_download仍失敗，category local_ai_network而無HTTP status；frozen phase／模型呼叫未執行；上述exact-host修補尚待新native，不能追溯確認舊失敗cause；mock、歷史14次呼叫或focused PASS均不能替代新路徑證據。
- **每日自動備份與審查修補已root套用，最終驗證仍待。** 預設off，開啟後app運作且所有manager閒置才嘗試，每UTC日最多一次；7份／2 GiB上限、連結保護、不自動刪檔或還原。獨立審查指出舊共用備份可經regular-file hardlink納入外部內容；共用BackupManager的hardlink拒絕已套用並包含於21項focused PASS。移除式磁碟離線時停用／更換目的地的設定恢復亦已修補，root focused23 PASS；最終combined／native未驗，不能宣稱漏洞或整項已完整閉合。
- **耐久與門檻不降級。** 舊來源同960 bars診斷worker35.562622秒，960次FULL cursor commits30.6026735秒，UI35.937秒；瓶頸位於耐久寫入路徑，物理原因未知。16974db3及最新e68b3301使用實際SQLite3.54.0／WAL／FULL，原960 bars／30秒測試已在Windows311／312 PASS；host為Windows Server2025，不能當clean client PASS。仍保留原per-bar耐久／帳本identity／風控與30秒、40秒、process-death10秒、job預算，不減bar／commit、不搬TEMP。不再無變更重跑湊綠，但經審查的新實作必須原生重驗。
- **執行責任與AI優先順序已更新。** 依使用者最新授權，assistant承擔工程、環境調查、可合法執行的設定與驗證，不預設把VM、測試或GitHub設定交給使用者。官方SIWC訂閱為必要路徑；本機模型與付費API／credits fallback禁止，不借用其他工具帳戶。零費用、零真資金交易及原驗收門檻保持。不可代行的帳戶、license、明示條款或持久權限，只提出精確最小確認，不包裝成整套技術作業。
- **外部證據如實保留。** 目前没有已驗證且已授權的零費用clean Win10/11 x64完整路徑；Win10／Win11官方EnterpriseEval x64媒體均可達，actual bundled EULA已以bounded ranges取出並核對檔案digest；full ISO hash、hosted-use涵蓋、registration／activation及owner接受尚未闭合，沒有Windows安裝／執行。opt-in KVM API12實際query已成功且close完成，沒有create VM或改權限；固定自撰payload execution self-test只有mock PASS、尚未執行；offline CI設計是提案，不是授權。KVM query成功不等於guest execution；Windows guest仍待資源／license／執行證據。SignPath僅可準備免付費申請材料，尚未獲接納。08:18只讀查核rulesets=[]、main保護仍未啟用；GitHub App無Administration scope，先前403未解除，換CLI／GraphQL／workflow token不會增加權限。實際服務、TAIEX盤中權利、clean client不以mock／Server替代。
- **原始匯入來源已有範圍明確的證據。** 原import `1cacce4ee4eef4ce7e8760f8153ef64a74852d22` 的47檔，其Git mode／type／blob全部與官方upstream `chrisli-kw/AutoTradingPlatform@a0ecf8895716bf5883184fdd27a52023f9700bf3`相同；upstream共49檔，另有`trader/APItest.py`與`trader/performance/backtest.py`未在該import。這證明47檔內容對應，不證明整棵tree／完整history相同，也不是維護者owner attestation；Apache LICENSE與Li Kuei-Wei署名保留。
- **210/300＝70%、M4 PARTIAL不變。** 17db263a兩個Windows core／Linux／UI PASS，但Windows312 research取消、SIWC第一階段已套用且有來源限定回歸，但新native／lifecycle未驗及loaded TLS／IME等範圍仍阻交付（原model_download失敗歷史保留）；其餘外部條件分開列示，不能把餘項全說成external。Oct8 WFO仍BLOCKED_NO_RUN，170 consumed bars、0新評估／model calls／reservation；不改window／registry。除上述使用者AI選路更正外，原需求、權重、失敗與歷史不重寫。

### 最後已驗證0088b505候選產物（不認證其後整合）

| 產物 | bytes | SHA-256 | 核對 |
|---|---:|---|---|
| PR artifact ZIP | 123732836 | `6565f25f56a2abf3be442a8762e12845205cbc7ecb337ad446a26e70c372ce94` | 32 entries／CRC PASS |
| 0.2.2 candidate EXE | 41777885 | `260076050a1794ade67a40b46b69cb148aafb9beda0ed56f07de6ef5a5b0554d` | 實際下載bytes一致 |
| 0.2.2 candidate clean-client kit | 82332787 | `02124210c7fc71a4de903fd3bb021ddb004f8f0ecf3d6d712676da961fe7b257` | 8 entries／CRC PASS |

Manifest source `703686e2a00a732fae87aad63fd638a2e2777675` 是實際PR merge，GitHub tree與受測head0088b505／localf10一致。60個build inputs皆符合原Git bytes或精確Windows CRLF轉換。Installed／upgraded／recovered／reinstalled／retained五份smoke均passed且user_state_read_only=true；真0.2.1 baseline recovery通過，977個原檔與5個sentinels保留。這些是候選來源與安裝證據，不能覆蓋Windows311原Paper30秒FAIL，也不等於Release或clean Win10／11验收。

### 原需求、設計提案與未驗證項目

- **本輪已明確必要的原需求：** Walk-forward，以及使用者原文 §5.1 的 Profit Factor／Sharpe、§3.4 的停損／停利／持倉成本參考線；已合併及PR階段PASS不等於postmerge／已發布交付。
- **尚未採用的完整目標設計延伸：** 04 §9.1 提出的 Average Trade、Sortino、Calmar、延伸分解與成本壓力測試保留為提案。02 歷史原文已明示「若最終採用該完整規格」；未取得使用者直接要求這些延伸的原始證據，因此不把設計表的「必須公開的計算與例外」升格為本輪新增驗收門檻，也不刪除提案。
- **尚未驗證的結果：** 修補後完整CI／發布、clean client、真實授權與真實研究各依目前證據判定；未驗證不表示功能未實作，設計提案未採用也不等於本輪驗收失敗。

## 當前優先風險與最小閉合證據

| 順序 | 風險／目前判定 | 下一個必要證據與依賴 |
|---|---|---|
| P0-1 完整CI與research累計cap | 17db Quantlab9 PASS；Win312 research完成208項、第209項db.commit時被15分鐘cap中斷、18未開始 | synthetic storage診斷已套用、獨立CI job已實作，不宣稱單一commit死鎖／已修好，不減工作量或放寬cap；保留各來源取消結果 |
| P0-2 必要官方SIWC／included-only | SIWC-only第一階段與本機AI移除已root套用、來源限定回歸如上；真grant／inference未驗 | owner授權與included-only自述前置；不可假稱可查證server credits或保證金額上限。本機工程證據不代替新native，舊下載FAIL保留 |
| P0-3 靜態payload與runtime分界 | 17db實際119 PE精確移除7項，retained DLL/PYD原hash、Python3.5.9與Qt notices已驗 | TLS有真loopback HTTPS、DLL載入仍mock；Windows loaded TLS／HTTPS／IME與source-release delivery仍需實際證據，不用pip-audit或靜態PASS替代 |
| P0-4 研究耐久與來源 | WFO single-normalization保留同hash bytes／全部COMMIT；Linux與Win311 research通過，但Win312取消仍在 | 後續storage調查不能改帳本／耐久／權重；Microsoft downstream充分性未定不是demonstrated breach，不擅加付費license／新EULA／collector gate |
| P1-1 普通操作 | expiry／typed Paper margin／TX-MXF分鐘入口與可讀表單已隨PR5合併main；仍非已下載0.2.1能力 | 修復發布否決後才核對實際Release；M2／M4均仍PARTIAL／0分，不提前採用條件式加分 |
| P1-2 必要研究與報表 | WFO／PF／Sharpe／參考快照／指南與普通UI已合併，PR完整1016與native/frozen通過 | postmerge整體失敗／Release未完成；fixed/saved pool不冒稱adaptive AI或真研究未見性 |
| P1-3 真實研究有效性 | Oct8 WFO 完整 guard 與已 consumed 170 bars 重疊，BLOCKED_NO_RUN；既有真模型負／零交易 | 不新增評估、不改 window／registry 規避；保留原完整 protocol／negative results。新的合格研究須另有合法且合規資料與預宣告；不得承諾獲利 |
| P2-1 client／AI／資料條件 | clean Win10／11 x64沒有已驗證已授權零費用路徑；官方SIWC真grant／bounded推論及盤中資料各待驗 | assistant承擔調查／準備／可執行驗證；只對帳戶／license／條款等不可代行操作精確確認，不預設使用者搭VM／測試，不以Server／mock補分 |
| P2-2 保護／簽章權限 | 08:18 rulesets=[]；main保護未啟用，App無Administration且先前403；SignPath尚未接納 | assistant準備最小權限／申請與政策方案；不借token、換transport繞403或擅開persistent access；沒有費用或免警告承諾 |
| 持續安全底線 | real money DISABLED；不消除未知請求、不重開研究／provider 預算；原門檻不降低 | 任一安全失敗獨立否決發布；不得用 70% 或舊 PASS 抵銷 |

### 外部路徑最新查核

- 免費clean Win10/11 x64仍未建立已授權可用方案。Win10／Win11官方EnterpriseEval x64媒體均可達，actual bundled EULA已以bounded ranges取出並核對檔案digest；full ISO hash、hosted-use涵蓋、registration／activation及owner接受尚未闭合，沒有Windows安裝／執行。opt-in KVM API12實際query已成功且close完成，沒有create VM或改權限；固定自撰payload execution self-test只有mock PASS、尚未執行；offline CI設計是提案，不是授權。證據：`quant-audit/windows-client-entitlements-followup-20261010.md`。標準public GitHub x64 runner是Server；Windows11 ARM不能代替x64。Nested guest僅實驗性，先查資源、合法精確媒體與license；不把無KVM的此shell推論成全部平台都不可能。
- SignPath Foundation可作免付費申請候選，但47檔內容對應並非完整history／權利attestation，PyInstaller／第三方binary界線、metadata、MFA／角色及privacy／signing policy仍需補證；沒有申請核准、證書或免SmartScreen承諾。Assistant先準備草稿與差距，不自行提交、接受條款或新增GitHub App／credential。
- 最新protection只讀結果rulesets=[]，Administration scope不在現有App權限內；REST／GraphQL／CLI或workflow token均不能自行取得它。保留exact-head release guard與Draft，但不稱其等於branch protection；精確權限核准不足只阻該操作，不中止其餘工程。

### 05:32及以前的歷史檢查點（保留原失敗，不是最新狀態）

以下1–6為先前來源／當時狀態；最新main與PR6結果以本頁交付摘要為準。

1. 已發布仍為0.2.1／main2ed1e3e，EXE／kit／manifest已核驗；版本0.2.2與PR5不變，新head不等於已交付。
2. 新remote12e088f／local2021cd7為同tree。Quantlab38026398885：Linux3111000項982PASS18skip／372.491秒，Linux312982PASS18skip／368.935秒，UI987PASS13skip／411.012秒；audit／static PASS。Windows311／312兩個15分鐘job CANCELLED，即使兩者原Paper30秒單項PASS，也不記整體PASS。
3. Server38026398890：1000項／918.891秒，4failures、2errors、14skips，包含原Paper30秒FAIL；build在新EXE前停止。六類失敗按上表保留，沒有用Linux結果覆蓋原生失敗。
4. 原生connection artifact（SHA-256前綴54cc9098）：10完整cases、FULL／NORMAL、每profile240commits，30children全部joined。每120commit的C DELETE reopen5.153／4.017秒、DELETE step4.439／3.929秒、PERSIST step5.764／5.902秒，D DELETE0.112／0.105秒。這支持I/O環境敏感度，不支持改產品storage、TEMP移動或宣告效能修好。
5. 05:32修補檢查：UI test-only57 focused＋25 independent PASS；WFO兩檔33 PASS／36.641秒；arity18 PASS／2.781秒；混合root85項84PASS1PowerShellskip／11.791秒。CI五檔partition獨立14 PASS，discovery1016唯一＝796core＋220research且精確無重疊；不是完整執行。後續native仍待，所有局部計數不相加。
6. 較早root773、候選981、root97／145及各native head都依原來源保留。981候選是在25檔精確複製前執行，不改稱root最終全套；本次1000項CI也不認證它之後的本地修補。Oct8實際WFO仍BLOCKED_NO_RUN，無新評估／模型呼叫。

歷史驗證位置補註：較早981項在隔離候選執行，25檔按manifest複製；不是最後root全套。12e088f的1000項失敗／cancelled與05:32局部18／33／85項屬先前checkpoint；其後06bcc3a的完整PR1016已通過，但94aca467 postmerge又出現上列兩種timeout。所有來源、平台及計數分開，不相加或追溯改寫。

最後原生受測PR #6 head17db263a／local1673d676／tree27a571ae：Quantlab9 PASS／Win312 research CANCELLED，Windows AI下載FAIL；119-PE靜態排除與notice核驗PASS。其後下載／TLS／storage／KVM delta已有本機full／focused證據，依來源分列，下一native待；全部歷史負面結果及210/300不變。

<!-- HISTORICAL_STATUS_END -->

## 歷史原文與逐次證據（依原記錄保留）

以下完整保留本次整理前的內容、要求、來源、失敗與各時點判定。內文即使寫「目前／最新」，也只屬原有日期快照；現在的交付與下一步以本檔最上方有日期的摘要為準。原始基線盤點、固定驗收條款與年代順序均未被當成新版本成功證據。


本文件區分已確認的原始碼缺陷、可能風險與尚未驗證的部署條件。優先處理會讓研究誤用交易權限、造成錯誤回測結論或容許未授權控制的路徑，再建立確定性測試。基線不具備可證明安全的無人值守条件。

## 1 範圍 方法與限制

查核日期為 2026-10-09 UTC；所有程式證據固定於 `1cacce4ee4eef4ce7e8760f8153ef64a74852d22`。當前安全修補與 `quantlab/` 屬後續開發，不改變歷史缺陷事實。修復是否成立以 [ACCEPTANCE.json](../agent/ACCEPTANCE.json) 的測試證據及變更 diff 為準，本文件不預先宣稱修復完成。

已執行的查核：完整檔案樹／blob 核對、38 個 Python 檔 AST 解析、相對匯入解析、重要控制流、依賴及設定檔盤點、完整可取得 Git 歷史文字掃描。未執行：產品匯入／啟動、套件安裝、broker／DB／通知登入、真實行情下載、憑證有效性測試、真實交易、依賴漏洞解算或滲透測試。

嚴重度定義：

| 等級 | 本文件判準 |
|---|---|
| Critical | 已證實可跨權限造成重大帳戶損害、任意程式執行並接觸秘密，或等同危害；本次沒有足以宣布已遭利用的證據 |
| High | 高後果的明確程式路徑，或會使交易／回測核心結論失真；部署可利用性可仍待核實 |
| Medium | 有條件可利用、可靠性／可維護性明顯缺口，需前置條件或限制範圍 |
| Low | 局部風格、警告與流程改善，不直接造成核心損害 |

優先度 P0／P1／P2 是修復先後，不等於嚴重度。關閉危險功能是一種暫時處置，不能等同整個舊交易平台已安全。

## 2 已確認的原始程式風格與品質

### 2.1 可保留慣例

- 模組責任已有基本切分，帳戶、訂單、部位、行情與圖表各有專屬檔案，便於隔離抽取。問題主要在相依方向及共享狀態，而非必須全盤換語言。
- `runtime.py` 使用 `Path`、部分型別註解與暫存檔替換，有照顧 Windows 檔案鎖定造成的 `PermissionError`。見 [檔案存取與重試](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/runtime.py#L24-L64)。
- GUI 啟動程序採參數 list 形式，靜態未發現 `shell=True`、`os.system` 或直接內建 `eval`／`exec`。見 [Popen 呼叫](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/gui.py#L100-L123)。這只是縮小特定攻擊面，不代表整個動態策略系統安全。

### 2.2 已確認技術債

| 面向 | 實際觀察與原始證據 | 影響與處理 |
|---|---|---|
| 命名及型別一致性 | 同檔混用 `check_can_stock`、`mapFunction`、`mapQuantities`；[命名樣本](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/strategy.py#L21-L45) | 新核心使用 snake_case 與完整邊界型別；不為風格全面重命名舊 API |
| 單一責任 | executor 同時組合 broker、DB、策略、模擬、通知、控制；[協調器](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/executor.py#L40-L65) | 抽出研究與執行 ports，而不是新增更多共享旗標 |
| 全域狀態 | `TradeData` 的帳戶、證券、期貨、報價及 KBars 共用；[狀態容器](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/objects/data.py#L9-L98) | 平行 trials 可能相互污染；改用每 run 獨立不可變輸入與帳本 |
| 隱含副作用 | 套件匯入建立目錄、API、資料庫與 table；[目錄](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/__init__.py#L16-L26)、[DB 初始化](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/database/__init__.py#L25-L42) | 不能安全匯入測試；建構生命週期要明確 |
| 靜默 fallback | `_read_json` 對廣泛例外回傳預設；缺失／壞命令日期不視為過期；[讀檔錯誤](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/runtime.py#L33-L40)、[日期錯誤](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/runtime.py#L112-L124) | 壞資料與「沒有資料」被混同；新系統記錄 typed error 並失敗關閉 |
| 缺值語義 | `_get_value` 將 NaN 填 0、缺資料回 0；[策略取值](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/strategy.py#L74-L94) | 真實零值、尚未 warmup、行情缺漏混淆，可能生成錯誤訊號 |
| 時間測試性 | 全域 TODAY 與當天 naive timestamp；[假日載入](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/config.py#L54-L76)、[時段](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/config.py#L159-L179) | 歷史回放依執行日改變；calendar 與 clock 必須顯式注入 |
| 多重責任與重複風險 | 訂單回報與庫存監控分散在 orders／positions／executor | 目前未量測 clone density，不宣稱某段一定冗餘；先統一狀態契約再決定刪除 |
| 無用程式判定 | 私有策略以動態 import 呼叫；[plugin 載入](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/config.py#L125-L150) | 靜態未引用不等於可刪；先保留，蒐集使用證據，不憑搜尋結果清除 |
| 語法與警告 | 38 檔 AST 通過，3 個 invalid-escape SyntaxWarning | 修正警告屬 Low；解析通過不等於 import／執行通過 |
| 測試與格式工具 | 全樹無測試設定、formatter／linter／型別工具設定；[測試忽略範圍](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/.gitignore#L133-L146) | 新增具版本工程慣例與測試追蹤；不假稱符合已不存在的標準 |

### 2.3 新核心工程慣例

以 [IMPLEMENTATION_CONTRACTS.md](../agent/IMPLEMENTATION_CONTRACTS.md) 固定型別與序列化契約。價格用 Decimal 點數並驗證 1 點 tick；金額用 Decimal TWD；口數拒絕 bool；時間為 aware UTC，另存交易日及 Asia/Taipei 規則。所有外部資料先驗證，未知欄位與缺少必要版本應拒絕。

Domain 層不匯入 UI、broker、DB driver 或外部模型 SDK。副作用由 adapter 負責，核心函數 deterministic；例外使用穩定類型與可診斷 reason code。新檔完整型別註解、清楚英文程式識別碼及繁體中文操作文件即可，不需要為了統一風格全面重排舊程式。

## 3 安全與正確性發現

| ID 等級 優先度 | 已確認事實與固定證據 | 後果與驗證限制 | 修復與驗收要求 |
|---|---|---|---|
| R01 High P0 | Shioaji 建構預設 simulation=False；`Mode='Simulation'` 與 `Simulate=False` 並存；[API 預設](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/config.py#L14-L16)、[API 建立](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/config.py#L79-L82)、[矛盾初值](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/objects/data.py#L9-L11) | 原匯入不是可靠離線邊界；未宣稱 bare import 本身會下單 | 研究完全不依賴 trader／shioaji；舊 live 路徑停用；缺少／未知模式一律拒絕 |
| R02 High P0 | Telegram 空白 whitelist 放行；[授權邏輯](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/bot.py#L168-L195)，可控制交易／口數；[控制功能](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/bot.py#L277-L438) | 配置 token 後可能被未授權訊息控制；沒有已被攻擊證據 | fail closed；stable user AND chat ID；空、缺、錯誤、未授權群組成員測試 |
| R03 High P0 | 全域 TLS 驗證覆寫；[HTTPS context](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/executor.py#L37-L37) | 受影響標準函式庫 HTTPS 可能接受攻擊者憑證；不推論所有 library 同受影響 | 移除覆寫；測試 source 無 bypass；以正常 trust store 修復憑證問題 |
| R04 High P0 | crawler 存在 verify=False；[HTTP 呼叫](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/crawler.py#L350-L350)、[下載與解壓](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/crawler.py#L610-L613) | 資料可能遭污染或耗盡資源；未實際證明任意 path traversal | 開啟 TLS、timeout／status／size／archive 白名單；MVP 先 local-only |
| R05 High P0 | SQL connection string 包含帳密並寫入 log；[DB URL](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/config.py#L111-L111)、[log 與連線字串](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/database/sql.py#L23-L44) | 運行時 DB credentials 可能外洩；庫内沒發現實際紀錄 | 診斷去敏、synthetic secret regression；部署 log 由授權者另行審閱 |
| R06 High P1 | report 匯入不存在的 `.backtest`；[缺少模組](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/performance/reports.py#L18-L18) | 無法把報告功能當完整回測；靜態缺失而非已執行例外 | 新建獨立 engine／report，不能用 placeholder 冒充回測通過 |
| R07 High P1 | actual 成本為 0，margin 僅 MX/TX，dropna 可丟 TMF；[成本與 margin](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/performance/base.py#L69-L81) | 淨利及報酬可能失真、TMF 記錄消失 | 明確 multiplier／fee／tax／slippage，ledger 對帳；禁止用當前 margin 套全歷史 |
| R08 High P1 | `iswin` 在空單損益反號前計算；[勝負判定順序](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/performance/base.py#L111-L116) | 空單勝率可能與最終 PnL 不一致 | 多空鏡像 golden；由配對帳本統一導出勝率 |
| R09 High P1 | calendar 限當年、缺檔 fallback 空假日、用 TODAY 判歷史；[假日](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/config.py#L54-L76)、[時段判定](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/time.py#L224-L242) | 休市、夜盤歸屬、跨年及到期可能錯配 | 版本化 session records；覆蓋不足即拒絕；官方交易日及公告優先 |
| R10 Medium P1 | `night_only` 文義存在但僅 day_only 有過濾；[盤別條件](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/kbar.py#L433-L454)；另有盤中時間 skip 與註解相反；[時間 skip](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/time.py#L124-L126) | 盤別統計及樣本選取不可靠 | 日夜盤邊界 fixture、clock 注入與文字／行為一致性檢查 |
| R11 Medium P0 | Redis `pickle.loads` 與 `pandas.read_pickle`；[Redis](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/database/redis.py#L78-L93)、[本機 pickle](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/file.py#L61-L61) | 若輸入可被攻擊者改寫，可能程式執行；本次未提供惡意內容或復現 | 新研究禁止 pickle；限制 legacy 信任來源並規劃格式遷移 |
| R12 Medium P1 | API key／secret／憑證密碼為普通資料庫欄位；[欄位](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/database/tables.py#L15-L18)、[表單寫入](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/gui.py#L304-L309)、[編輯寫入](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/gui.py#L550-L555) | 畫面遮蔽不是加密；未知部署是否有反向代理認證 | GUI 暫限私有使用；secret store 與部署權限須另立授權驗收 |
| R13 Medium P1 | account normalization 可保留 `.`／`..`；[原始識別碼規則](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/runtime.py#L24-L28)；GUI 直接組日誌路徑；[路徑](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/gui.py#L92-L94) | 共享控制／檔案邊界不足；未嘗試越界寫入 | 嚴格 allowlist ID，拒絕 dot segment／separator，驗證輸出 root |
| R14 Medium P1 | sample 在類別定義呼叫 `Position()`；[範例](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/docs/script%20samples/strategy_sample.py#L102-L109)，建構需帳戶與策略；[必要參數](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/positions.py#L815-L821) | 範例不能原樣執行；資料亦為佔位路徑 | 替換為離線、可驗證範例；保持新老範例狀態區分 |
| R15 Medium P1 | 32 項直接依賴無完整 lock/hash；[依賴](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/requirements.txt#L1-L33)，無 CI／測試 | 供應鏈、環境重現與版本漂移風險；未執行漏洞掃描 | 隔離研究依賴；固定適用環境，SBOM／授權及漏洞掃描另驗收 |
| R16 Medium P1 | 共用狀態、動態 Python 策略、無實驗 provenance；[耦合](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/strategy.py#L6-L12)、[共享狀態](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/objects/data.py#L9-L98) | AI 不能安全直接生成可執行程式；trial 污染難追溯 | schema／AST 白名單、每 run 空間、版本及資源限制 |
| R17 Low P2 | 命名、型別、docstring、警告與 fallback 慣例不一 | 增加維護與審查成本，不等同每處皆漏洞 | 在新增及實際修改範圍漸進改善，禁止無目的大重排 |

R11 的條件若擴大為不受信任者可寫入、且交易程序持有秘密，嚴重度應上調；未調查部署前不直接宣告 Critical。R01–R05 先隔離或停用，避免開發時進入高風險路徑。

## 4 可取得歷史的秘密掃描

### 4.1 覆蓋範圍

- remote advertisement 與 refs 查核只有 `refs/heads/main`；HEAD 為 符號別名，未見其他 branch 或 tag。當時所有狀態 PR 清單為 0。
- 完整非 shallow clone，Git object 完整性檢查未回報錯誤。
- 掃描兩個可達 commit：目前基線及根 commit `eb462f9dcde9b7a446be8ed902eeb629f7f39f1a`。根 commit 無 parent。
- 48 個唯一可達 blob，共 425,164 bytes；HEAD 47 檔，額外歷史內容為較早 README。
- 使用 inert 文字／regex 檢查 private-key header、常見 token 格式、JWT、URL 帳密、字面 credential assignment、高 entropy 字串。沒有匯入產品或對任何服務試用候選值。

### 4.2 結果與處置

**未發現高可信度已提交憑證或私鑰。** 這是有範圍的靜態結果，不是「完全無秘密」保證。[第三方資料 URL 組成](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/crawler.py#L283-L340)有一個低可信度短字面值，用於共享 CDN 路徑；其是否被供應商視為 access credential 尚不明。公開報告不重貼該值，也不因此要求輪替無關帳戶。

未找到追蹤中的 `.env`、私鑰、broker certificate、帳戶 database、`config.ini` 或 log。忽略規則可以降低新檔誤入版控，不能保護已追蹤或已外傳的檔案。

不涵蓋刪除／未公告／不可達遠端 object、fork、release artifact、issue comment、外部系統及未追蹤部署檔。兩個 commit 不足以證明最初完整開發歷史。若日後確認真憑證曝光，應由擁有者先撤銷／輪替並稽核使用紀錄，再討論歷史清理；只刪程式字串不會消除風險。

## 5 工程合規矩陣

此處「合規」指本專案工程慣例符合度，不是法遵認證。`符合` 有限定範圍；`部分` 有實作但不完整；`缺少` 是完整基線未找到；`BLOCKED` 需要外部或執行證據。沒有可引用檔案的缺失列明完整固定樹，不能編造行號。

| 控制／慣例 | 基線判定 | 固定證據 | 最小補強與驗收 |
|---|---|---|---|
| 原始碼可定位及語法解析 | 符合，僅靜態 | [固定完整樹](https://github.com/yostar77612/mark-auto/tree/1cacce4ee4eef4ce7e8760f8153ef64a74852d22)，47 檔／38 AST 通過 | 變更後重新解析及測試，不能沿用歷史結果 |
| License 與原作者標示 | 部分 | [Apache-2.0](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/LICENSE#L1-L15)、[著作權](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/LICENSE#L189-L189) | 保存通知與修改標示；完整上游來源仍待核對 |
| 無直接 shell 字串執行 | 符合，限本次掃描模式 | [list Popen](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/gui.py#L100-L123)；全 38 檔 AST／文字檢查 | 不擴大成所有動態程式皆安全 |
| 模組匯入純淨 | 缺少 | [副作用](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/__init__.py#L16-L26)、[DB 建立](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/database/__init__.py#L25-L42) | 新核心 import graph／拒網路／拒秘密測試 |
| 實盤失敗關閉 | 缺少 | [預設 live](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/config.py#L14-L16)、[送單分支](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/orders.py#L843-L897) | 不可由單一 flag 啟用；LiveBroker 拒絕所有操作 |
| TLS 驗證 | 缺少 | [全域覆寫](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/executor.py#L37-L37)、[下載 bypass](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/crawler.py#L610-L613) | 移除全部 bypass 並靜態回歸 |
| 操作身份驗證 | 部分 | [白名單失敗開放](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/bot.py#L168-L195) | stable numeric ID、空白拒絕、群組成員測試 |
| 日誌不包含秘密 | 缺少 | [connection log](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/database/sql.py#L23-L44) | central redactor、synthetic credentials 測試 |
| 不受信任輸入安全 | 部分 | [pickle](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/database/redis.py#L78-L93)、[下載](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/crawler.py#L610-L613) | typed JSON／CSV、大小／欄位／輸出路徑檢查 |
| 型別與時間一致性 | 部分 | [型別與 naive 時間](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/runtime.py#L97-L124)、[全域日期](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/config.py#L159-L179) | Decimal／aware UTC／交易日分離；邊界錯誤顯式化 |
| 訊號資料缺漏處理 | 缺少 | [缺值變零](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/strategy.py#L74-L94) | 缺值／warmup／真零值分開；不補造行情 |
| 成本後帳務可信 | 缺少 | [費用零與 margin](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/performance/base.py#L69-L81)、[空單勝率](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/performance/base.py#L111-L116) | 手算 golden、lot matching、費稅版本 |
| 不可變研究 provenance | 缺少 | [完整固定樹](https://github.com/yostar77612/mark-auto/tree/1cacce4ee4eef4ce7e8760f8153ef64a74852d22)，無 manifest／trial store | spec／data／engine／config hash 與全部嘗試 |
| 測試、CI、依賴鎖定 | 缺少 | [僅直接依賴](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/requirements.txt#L1-L33)、[測試忽略](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/.gitignore#L133-L146)；樹無 workflow | 測試可追蹤、最小權限 CI、fresh checkout |
| 第三方套件授權與漏洞清單 | BLOCKED | [需盤點的直接依賴](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/requirements.txt#L1-L33)；無 transitive lock／SBOM | 在選定環境建立精確版本清單、授權與漏洞報告 |
| 券商、資料授權與無人值守 | BLOCKED | [broker 登入](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/utils/accounts.py#L59-L78)；無新 broker 認證或持久故障驗收 | 正式文件、資格、授權、RPO／RTO 演練，另行核準 |

## 6 威脅模型與必要控制

| 信任邊界／資產 | 攻擊或故障情境 | 控制與保留證據 |
|---|---|---|
| 公開 repository／CI／產物 | 誤提交秘密、PR 執行外部程式偷取權限 | 全歷史範圍掃描、低權限 CI、外來 PR 無 secrets；公開 artifact 僅合成資料 |
| 下載檔案與資料匯入 | 巨檔、壓縮炸彈、惡意 pickle、錯欄位或污染行情 | MVP 拒 URL 自動抓取與 pickle；限制檔案／列數，驗證 schema、range、hash 與 calendar |
| 外部文件與模型輸出 | prompt injection 要求改門檻、執行 shell、看秘密或送單 | 外部文字僅資料；模型只輸出有限 DSL；確定性驗證器與最小權限阻擋能力擴張 |
| 研究候選至策略庫 | 用最佳回測結果悄悄改成本、split 或版本 | 鎖定接受標準、內容雜湊與 all-trial log；任何變動新增版本與重新驗收 |
| 訊號至執行 | 重複 intent、行情過期、超量或 margin 不足 | risk gate、唯一 client_order_id、account snapshot age、hard limits，拒絕原因記錄 |
| 送單至回報／重啟 | ACK timeout 但單已接受、部分成交、取消競速、漏回報 | 持久 intent／事件、UNKNOWN 停新單、查詢及三方對帳，不盲重送或補償下單 |
| 操作者控制平面 | 未授權 bot 成員或 UI 使用者改部位限制 | 身分與情境雙檢查、最小權限、變更稽核；策略無權修改交易權限 |

依據 [NIST SSDF 1.1](https://csrc.nist.gov/pubs/sp/800/218/final)、[NIST SP 800-218A](https://csrc.nist.gov/pubs/sp/800/218/a/final)作工程控制參考，不宣稱認證。Prompt injection 不可僅靠模型提示解決，應限制工具權限並驗證輸出，參考 [OWASP LLM01](https://genai.owasp.org/llmrisk/llm01-prompt-injection/) 與 [LLM06](https://genai.owasp.org/llmrisk/llm062025-excessive-agency/)。

## 7 License 與供應鏈判斷

基線 LICENSE 為 Apache-2.0，包含既有著作權；再利用時需保留適用 license／notice、合理標示修改，不能把原始程式改稱全為新作。本次樹未見 NOTICE，不能因此推論上游從未有 NOTICE。[MDD 程式引用](https://github.com/yostar77612/mark-auto/blob/1cacce4ee4eef4ce7e8760f8153ef64a74852d22/trader/performance/base.py#L211-L213)另指向外部演算法來源；完整來源及其適用授權仍需查證。

第三方依賴包括 Shioaji、pandas／NumPy、SQLAlchemy／MySQL／Redis、cryptography、HTTP／HTML、Telegram、Streamlit／Flask／Dash 與繪圖工具。多數直接版本固定，但 pytz 只有下限；沒有 transitive lock、source hash 與完整套件 license 清單。`urllib3` 有直接匯入卻依賴 requests 間接帶入，亦應明列或移除該耦合。

因此本次可確認 repository 自帶授權文件，**不能確認所有上游及第三方再散布條件已滿足**。交付可發布程式前，對實際選定的研究與 UI 環境輸出 SBOM，核對確切版本 license、保留所需通知，確認 broker SDK 及行情資料另有服務條款。Apache-2.0 不授予第三方市場資料重製權，也不提供券商帳戶操作權。依賴版本老舊是風險線索，未完成當前漏洞掃描前不列猜測 CVE。

## 8 優先修復及釋出阻擋條件

1. **P0 安全邊界：** 研究不匯入舊交易樹、live 固定停用、Telegram fail closed、TLS 修復、DB log 去敏、危險反序列化不進新核心。不能因架設了新 UI 就略過舊入口仍可啟動的風險。
2. **P1 正確性：** calendar／資料品質／TMF contract／cost／causal engine／lot ledger，用獨立 hand-calculated golden 驗收；修復 sample 與 tests ignore。
3. **P1 工程基礎：** 版本、固定接受標準、離線 test entry、CI、all-trial log、hash；研究與策略績效分開驗收。
4. **P2 可用性：** 可追溯 UI、錯誤訊息、恢復操作、效能基準，避免以圖表或漂亮 Sharpe 遮掩未驗證部分。

未解決的高後果執行路徑、失敗的因果／帳務 golden、無法追溯的資料、越權模型輸出或 UNKNOWN 仍放行新單，均是一票否決的釋出阻擋條件。分數再高也不補償安全失敗。實際模型、真實市場策略表現、券商認證及實盤仍保持獨立 readiness，不能由 Mock 或合成資料測試代替。


## 自主實作後複查（2026-10-09）

以下是原始基線分析之後的工程處置，不回寫或混淆上方固定 SHA 證據。新 `quantlab` 研究樹不匯入券商 SDK；舊交易入口、危險反序列化與舊 ZIP 路徑已封鎖。實際修復與測試證據分別在 `tests/test_legacy_security.py`、`tests/test_architecture.py`。新資料下載 `quantlab/downloads.py` 有官方 HTTPS 白名單、大小／CRC／路徑及壓縮比限制，快取保留內容 SHA，未完成品質驗證的資料不能標為正式排名可用。

最後審查另發現 provider 端點在 HTTP 呼叫前可能被記入 campaign：即使 transport 拒絕有帳密的 URL，研究初始化仍可能先保存它。已於 `quantlab/research.py:CompatibleProvider.__init__` 提早拒絕 userinfo、query、fragment、非法 port 與控制字元，錯誤不回顯 URL；`tests/test_research.py` 驗證拒絕發生在序列化與 budget 目錄建立前。這是防洩漏修復；未發現實際使用者憑證遭寫入。

本地最終產品提交 `e5e56bb` 的完整可達掃描包含 7 個提交、132 個不同 blob、1,360,512 bytes，非 shallow；未找到高可信度密鑰。比對命中為合成負向測試、cost_per_token 名稱誤報及既有 CDN 路徑常值（仍保留待核实風險，不顯示其值）。靜態樣式掃描不能保證不存在秘密，也未測試任何疑似憑證有效性。後續文件提交以增量檢查驗證。

全套本地與 fresh-checkout 各 177 項測試通過、無 skip，包含 5 個 UI AppTest；wheel／sdist 成功建置，wheel 不含 legacy trader。Windows／Linux 遠端 CI、整合 SHA 與最新進度以 `../agent/PROJECT_STATE.md` 為準，不能把此本地結果当成 Win10／Win11 桌面安裝驗證或長期實盤就緒。


## 桌面整合風險與已執行修復

- 中斷還原與安全凍結競態：舊資料移到rollback後若先重建state再恢復，會危及原資料。現實作先join/cancel寫入程序，再恢復，最後才能寫安全狀態。刪除rollback必須有相符的durable commit identity與promoted token；模糊狀態隔離保存，不猜測成功。測試注入兩次rename之間中止、未退出worker與journal清理中斷。
- 研究控制狀態回退：支出預留與已見holdout原先在可還原state內。現移到固定bootstrap/control-v1，舊備份／同bootstrap切換工作區不會重開預算或已消耗保留集。舊in-state控制帳本存在時阻擋新研究，不自行刪除或假定新帳本。這不是對使用者任意複製至另一台電腦的全域防作弊或帳單保證。
- 候選資格資料被單獨修改：JSON結果須與唯讀SQLite authoritative state一致，並核對selection hash、策略與資料綁定；未合格的OOS／holdout不能在桌面啟用Paper。無法防禦同一OS帳號惡意改寫全部檔案，這個信任邊界須保留。
- 凍結版來源完整性：six engine sources明確列入PyInstaller資料，安装後與source SHA逐檔核對。只有demo啟動不足；smoke必須完成真正凍結版backtest、bounded fixture campaign及paper流程。
- Windows資源與輸入：終端錯誤訊息與子程序退出同步，失敗不被清理誤標成使用者取消；固定bootstrap lock和命名mutex避免切換工作區重複啟動；DPAPI、Job Object取消／父程序當機及junction拒絕以Windows integration tests驗證。
- 供應鏈：桌面使用官方有Windows二進位安全更新的CPython3.13.16，取代3.12.10；版本／SHA／官網來源在 `packaging/python-runtime.json`。Qt6.12是Win10支援線，不能盲升不支援Win10版本。安裝器未簽章，不绕過Windows警告。

本地fresh checkout `8bc19e1`：258 tests，共253 PASS與5個Windows限定項未在Linux執行；兩套UI測試均實際執行。遠端同tree為 `d0665e1417a6c31d0978e93a9bf2d2194eba913d`，Windows最終結果須獨立讀CI。Linux Qt可見視窗＋worker smoke單次0.932秒、子程序最高RSS83,908KiB；不是Windows首屏或效能SLO。先前1000bar回測中位0.522秒屬合成基準，不作市場資料吞吐保證。

上述桌面處置的可定位證據：`quantlab/desktop_runtime.py`（`JobManager`、`WorkspaceLocator`、`DesktopCredentialReference`、backup/restore 與 recovery）、`desktop_ui.py`（`_quiesce_and_recover`、候選啟用與設定事件）、`tests/test_desktop_runtime.py`、`tests/test_desktop_ui.py`、`packaging/markauto.spec`、`packaging/test_installer.ps1`。Windows CI 尚未全通過時，這些是已實作／部分驗證，不是所有平台驗收完成。

### 當前符合度與殘餘風險

| 分類 | 當前狀態 | 證據與限制 |
|---|---|---|
| 核心因果、帳務與 Golden Cases | 工程 Gate 已符合 | `tests/test_backtest.py`、`tests/test_strategies.py`；市場參數與資料涵蓋另驗 |
| 模型任意程式執行與券商隔離 | 已符合目前受限研究架構 | `quantlab/strategies.py`、`provider.py`、`tests/test_architecture.py`；不執行模型 Python |
| 研究洩漏、預算與版本 | 工程控制已建立；桌面部分驗證 | `research.py`、`desktop_runtime.py`、相對應 tests；真模型／正式資料未驗證 |
| 桌面安全恢復、DPAPI、單例 | 已實作；Windows 最終 Gate 尚待修復重驗 | runtime／UI tests；不得以 Linux skip 當 PASS |
| 自動品質／憑證／依賴 Gate | 已建立並實際執行 | `.github/workflows/quantlab.yml`、`windows-desktop.yml`、`tools/quality_gate.py` |
| main 強制保護 | 缺失且管理權限阻塞 | GitHub metadata `protected=false`、rulesets 空、protection API 403；流程自律不等於服務端防護 |
| 乾淨 Win10／Win11 驗收 | 缺失，外部環境阻塞 | D7／D8 BLOCKED；Windows Server 不可替代 |
| 正式即時交易、券商認證與長期無人值守 | 缺失／未驗證 | `LiveBroker` 停用、Paper 歷史批次；須獨立資格與實際故障演練 |
| 長期資料與正式策略排名 | 部分符合 | 官方下載與品質框架存在；30 個 ZIP 不能證明完整歷史或有效樣本外 |

立即優先處理所有實際失敗的安全／恢復 Gate；其後才可發布預覽。正式交付仍受 clean client OS、資料與外部連線驗收限制。無證據的憑證「未外洩」、長期穩定性或交易績效結論一律不得宣稱。

### Windows 工程驗證結果（17:21 UTC 更新）

來源 `3246cdc`／遠端 `b62803a` 已通過 [Quantlab 七 jobs](https://github.com/yostar77612/mark-auto/actions/runs/37964547136) 及 [Windows installer build／安全 Gate](https://github.com/yostar77612/mark-auto/actions/runs/37964547102)。Windows Server2022 Python3.13.16 完整 suite 263 tests：256 PASS、7項 Linux／選用 Streamlit 未執行，其適用情境由 Linux jobs 覆蓋；DPAPI、JobObject、mutex、junction、真 PowerShell parser 均實際執行。WinError109正常 EOF 誤分類及短路徑已修正，不再阻擋此來源整合。

安裝測試通過 frozen 七步研究／Paper、程式來源 hashes、捷徑、正常視窗、升級、拒绝正在執行時更新／移除、正常關閉及解除安裝後資料保留。此處升級fixture使用同payload的0.0.0→0.1.1，**不是歷史資料 schema migration 證明**。移除PATH工具不是乾淨機；D5、D7、D8仍 BLOCKED。驗證產物包含OS／版本／執行結果與單次效能觀察，不作client OS或長期無人值守承諾。

## 0.1.2 接續驗收與新發現（2026-10-09）

此節優先於前文歷史快照，並保留缺陷原始事實。0.1.1已交付的是unsigned preview，不代表安全與產品驗收結束。

| 風險／原本缺口 | 本輪處置與證據 | 驗收界線 |
|---|---|---|
| High：備份目的地可覆寫control-v1帳本／bootstrap指標 | `BackupManager.create`在任何恢復/寫入前拒絕active workspace及固定bootstrap內目的地；`test_desktop_runtime.py`覆蓋所有sentinels及搬移工作區 | 外部備份成功且內部資料保持；Windows整合仍須重跑 |
| High：Paper衝突duplicate、截斷fill或SQLite恢復後仍可能送新單 | `paper.py`持久quarantine及同程序storage-uncertainty latch；`test_paper.py`／`test_paper_replay.py`新增12案例，61focused tests | timeout模擬、實際SQLiterollback／程序當機，不是假稱真券商重連 |
| High：official/proxy資料缺盤首／盘尾／整盤仍可匯入 | `data.py`共用_dataset完整calendar coverage，新增5回歸；synthetic短fixture保留明示warning | 真Oct7缺03:29–03:30被拒絕，不能補造bar |
| High：overlay更新殘留舊DLL／中斷混合runtime | `markauto.iss`每次全新payload、編譯綁定inventory與全部檔案hash後才啟用捷徑；`test_update_recovery.ps1`實際kill安裝程序驗收 | Windows實跑前不計PASS；保留旧payload會占磁碟，不任意刪使用者檔案 |
| Medium：發布來源可不是main、任意單job成功可混充完整Gate | `wait_for_gates.py`檢查main ancestry及7個必要named jobs，全數成功才發布；`test_release_provenance.py`負向測試 | 不等於main服務端保護已啟用 |
| Medium：真小模型不理解未提供的DSL／自由JSON不可靠 | `research.py`明示schema/train-only context，新增可選registry_json_schema；desktop設定持久化且預設budget identity不變 | 前6calls失敗保留，structured3calls有效；無默默fallback，不宣稱任意AST可靠 |

### 真實整合結果

免費官方Qwen1.5B的3個受限家族參數候選，經原生provider/HTTP→train/validation→固定選擇→OOS/holdout→多策略比較完成。這是實際推論，不是mock。Trend的OOS為-33,820、holdout為-49,546 TWD；另兩候選各split零交易，不能視為最佳獲利策略。資料僅12日，費用/保證金屬明示假設，沒有經濟／實盤資格。資料、模型、runtime與請求回應的hash及全部失敗紀錄保留供重現；原始行情不發布至Git。

官方12日資料為2026-09-17至10-06同一TMF202610契約，13,680根分鐘K、24盤OHLC符合另一官方日行情；2026-10-07缺1分鐘，拒絕而不判定一定是資料故障（也可能無成交，無證據不能補bar）。免費2025年度日行情涵蓋243交易日，但不能轉稱分鐘級歷史。到期日依[官方年度calendar](https://www.taifex.com.tw/file/taifex/CHINESE/4/2026Calendar.pdf)與[TMF規格](https://www.taifex.com.tw/cht/2/tMF)核驗為已公布10/21台北13:30；後續正式公告可再變更。

### Windows／簽章／權限的實際限制

[Windows11 Enterprise](https://www.microsoft.com/en-us/evalcenter/evaluate-windows-11-enterprise)有90日評估管道，涉及註冊、既定授權條件及可用VM；不是永久免費授權。Win10舊evaluation URL目前導向終止支援資訊；[ISO媒體](https://www.microsoft.com/en-us/software-download/windows10ISO)存在不等於新VM已有免費授權。未下載非官方OS、接受新協議、繞過啟用或使用付費試用。現有Linux無KVM且無授權clean client；無法以Server／ARM／PATH隱藏工具冒充Win10/11 x64。

EXE仍unsigned；ASLR/DEP靜態存在不等於通過全面安全檢測。[SignPath Foundation](https://signpath.org/terms.html)免費簽章有OSS資格、MFA、角色/政策與人工批准要求，尚未核准；Store的免費簽章針對其MSIX管道，不會自動簽既有EXE。[SmartScreen](https://learn.microsoft.com/en-us/windows/apps/package-and-deploy/smartscreen-reputation)亦可能警告已簽章的新檔，不建議繞過保護。沒有購買或建立簽章憑證。

main仍protected=false、rulesets空，管理級API403。Code/PR/Actions正常，不代表具管理授權。此限制維持EXTERNAL BLOCKED；未申請擴權或假裝保護啟用。

### 真模型改善迴路補驗

另以獨立明示 synthetic 512 bars 驗證一次初始生成＋一次改善，未重用真實OOS/holdout。第二次真HTTP請求包含先前train/validation回饋、改善指令與parent/iteration；模型只將trend_0改名trend_1，fast=2/slow=4未變。正規化語意指紋忽略名稱、等價數值及default lag/quantity，成功拒絕重複而保留raw/call/父鏈，沒有重跑回測。工程feedback/去重PASS；有效不同改善候選FAILED，績效改善不成立，不能寫成外部授權阻塞。累計11次真推論已停止；研究40、provider8、真AI工具9 focused tests通過。

## 新增市場/UI範圍的實作前安全界線

舊trader行情工具有全域交易初始化，不能直接解除封鎖或匯入桌面；新增僅讀市場型別與TMF交易資料分開。TX/MXF/index行情展示不等於其回測或下單引擎通過。官方小台每日原碼MTX與UI MXF需明示映射；價格前收與前结算不可混用（實際10/8 TX前收差-630、官方前結算差-619）。日資料日期不代表精確成交時間，缺OHLC不得由成交量猜補，公開歷史不得冒充即時。

OpenAI現在有[官方OSS/本機Sign in with ChatGPT計畫用量](https://developers.openai.com/siwc/token-sharing-open-source)途徑，並非一般API免費額度。需要本應用自己的使用者授權、PKCE/OIDC驗證與安全儲存，不能拷貝其他工具token。HTTP Responses/SSE與既有chat-completions協定不同；不支持max_output_tokens時，客戶端截流/逾時不能聲稱限制伺服器token消耗，須獨立透明用量政策。實際登入/授權與帳戶可用性尚未驗證；付費API與額外credit不自動啟用。

### 0.1.2 Windows實測與正式保留證據（2026-10-10 00:38 UTC）

PR#2已合併28c9f902，最後head9008522完整tree6338b6ef9828892e53fbf1a543ada0ec9bd8f154與本地ccb74d2等價；Quantlab7jobs38008659312、Windowsbuild/security38008659297全PASS。Windows測到原inventory排序隨OS不同及NTFS ADS未被rglob看見，已修productioncode固定排序並列舉拒絕ADS；失敗測試沒有刪除/跳過/降門檻。341測試334PASS、7適用其他環境/選用工具skip。

合併後38009150044在WindowsServer2022build20348完成真0.1.1→0.1.2、安裝程序實際kill、舊runtime恢復、新payload驗證啟用、保留927個原檔及5資料sentinels、實際schema1設定位元不變，並完成同版本重裝修復split-shortcut。這是單一程序當機點，非完整斷電耐久證明；compatible設定保留不是跨schema migration。原生命週期10checks也PASS。單次啟動1.033秒、working set77,676,544bytes，不是Win10/11SLO。

[Release與驗收工具包](https://github.com/yostar77612/mark-auto/releases/tag/desktop-preview-38009150044-1)已實際下載：EXE36,695,486bytes、SHA256 0f92f70fb17bc3f0c2c816cbb5f963ecb2de6dde40745759f415a4755e85c469；kit72,324,965bytes、SHA256317f98560ae1c29ee4d7c99e81ed2d8bab55d010114f765b756cdcd9ae076079，ZIPCRC通過。Win10/11clean、main管理權限與簽章限制未因此解除。

### 0.2.0 市場模組架構 Gate 修復（2026-10-10 00:46 UTC）

靜態Gate發現3個Qt檔案放在quantlab研究樹，違反既有stdlib-only邊界；沒有放寬研究規則。已將desktop_charts.py、desktop_forms.py、desktop_market.py移至既有desktop_ui.py旁，UI向quantlab資料/策略依賴，核心不依賴Qt；同時把既有desktop禁止券商/dynamic-execution掃描延伸到全部4個UI檔，新增負向回歸。證據：tools/quality_gate.py、tests/test_quality_gate.py。可選Qt測試遵循原矩陣分層，在有完整桌面依賴的Windows job必須執行；minimalstdlib job明示skip，不能算桌面PASS。

最新報價卡與歷史圖表分離；只持有較新已驗證分鐘history時可以顯示卡，但不升格為即時。日期/盤別無法排序時不虛構日行情時間。證據：desktop_ui.py與tests/test_desktop_market_integration.py。官方直連DNS失敗保留BLOCKED；本地匯入標history/source-unverified，不能以URL字串證明來源真實性。

CI run38010756018揭露deadline測試fixture競態：30ms計時包含SSL初始化，慢runner在fake connect前合法逾時。未放寬產品30s限制或測試0.5s關閉門檻；僅隔離handler時計，仍以真30ms threading.Timer驗證shutdown，新增已逾時不連線案例。23focused、200重複及10次故意60ms SSL初始化均通過；原失敗保留，下一head重新驗收。desktop.py另把原7步frozen smoke保留，再增加獨立synthetic market_smoke（真Qt非空圖表/週期/指標/typedforms、manual export/import worker與來源hash），任一失敗阻擋overall。這是打包工程測試，不是行情/AI實測替代。

同次Windows CI另發現payload path驗收把原字串和GetFullPath結果要求完全相同，可能誤拒TEMP含8.3別名的合法路徑。改為canonical target/trusted root比對，同時明確拒絕relative/drive-relative/UNC、dot traversal、ADS；原精確layout/reparse門檻保留，動態測試增加ShortPath。來源packaging/test_update_recovery.ps1、tests/test_update_recovery.py；Windows需重驗，Linux skip不作成功。新市場/原7步整合source smoke及其完整Linux suite459項451PASS8skip（72.056s）；另最新recovery focused10PASS1Windows skip。原失敗CI不能被這些本地結果抹除。

第二輪 e066693 的Quantlab七jobs全部PASS，Windows build及frozen市場/原7步、安裝生命週期通過，官方日行情實際HTTP下載診斷VERIFIED。接續歷史版本恢復驗收正確阻擋了前一輪正常關閉留下的設定：新UI會保存市場/視窗偏好，而uninstall保留資料。處置不刪設定或降低hash驗收：lifecycle明示opt-in且啟動前證明設定/工作區指標不存在，完成後寫create-only ownership receipt；recovery驗version/path/hash後將已知test-owned設定搬至唯一保留副本，未知資料仍拒絕。--smoke-test另採載入已驗證真設定後的記憶體view，僅自動化測試不回寫偏好；正常GUI持久化不變。來源desktop.py、tests/test_desktop_market_smoke.py、兩支installer/recovery harness與對應tests。失敗診斷artifacts改always保留，但release依賴必要Gate不變。最新Windows重驗前仍BLOCKED。build manifest涵蓋全部desktop*.py，包含新chart/form/dashboard來源。

## 0.2.1 官方訂閱整合安全驗收（實作中）

官方授權與Responses SDK邊界置於root desktop_chatgpt_auth.py／desktop_chatgpt_provider.py／desktop_chatgpt_ui.py；quantlab仍僅stdlib，唯一既有runtime→desktop_ui橋接維持。新增檔案納入原禁止券商匯入/動態程式執行Gate。沒有實際OAuth授權或訂閱推論，所有fixture僅為工程測試。

重點威脅與驗證位置：
- 授權callback重播、錯host/state/nonce/audience/issuer、JWKS不明key、RS256演算法混淆：auth模組及test_chatgpt_auth.py；使用PyJWT驗簽而非自製密碼學。
- 明文凭證、跨使用者檔案、junction/鎖/refresh中斷：DPAPI vault、private DACL與tests/test_chatgpt_windows.py，只有實際Windows測試通過才可列native PASS；Linux skip不計。
- 跨研究/模型/工作區重置支出或未知請求重送：固定bootstrap control帳本、先預留/不退還、帳戶暫停及嚴格完整receipt。獨立審查曾實際重現「global DB遺失後新研究可重建」和「campaign DB遺失被當空receipt」；已列release-blocking待修復，不得以一般SQLite交易成功忽略資料遺失情境。
- 父程序被取消但子孫仍推論：desktop_runtime整個process group／Windows Job active count，以及same-manager停止證明/不可變launch snapshot。terminal IPC packet不等於已退出，未知狀態禁止新操作；tests/test_desktop_chatgpt_integration.py含忽略TERM子孫反例。
- 不可信新provider稽核資料：research.py限制descriptor深度/大小與receipt欄位、sequence、status、hash，未知結果在下一trial/selection/holdout前阻擋；outer中斷只進行本機exclusive-lock對帳，保存既有attempt/holdout，不重新產生任何結果。

四個desktop-only依賴固定PyJWT2.15.1、cryptography50.0.2、cffi2.1.1、pycparser3.11，wheel digest與雙平台manifest保存。native attribution以已獨立審閱的固定ZIP交付，不解壓不可信archive至產品路徑。archive完整SHA256 cbf2c6123cd25e53b33e766fb27bea9c9b4d8d174deb5ae54519d07f62dc9b24，含93個hash驗證檔與manifest；5個來源archive403仍如實記錄，必要notice以官方immutable Git物件補證，不宣稱archive全部下載。詳細inventory在packaging/third_party及發行licenses ZIP。這是工程授權清單，不是法律保證。

完整桌面smoke另呼叫offline auth_smoke：新鮮synthetic RSA key、真native OpenSSL/CFFI/parser、實際IdentityValidator、錯nonce/audience與algorithm rejection；socket/DNS當場阻擋並恢復，沒有寫入真vault或授權。real_oauth_status及real_model_status保持not_verified。Windows frozen與實際帳戶需各自證據。

01:28 UTC補驗：上述missing-control release blocker已在staging修復，原failed repro保留。bootstrap建立create-only/fsync marker（不隨workspace/backup回退）；marker、global DB、schema或已登記campaign ledger任一遺失／部分初始化／count回退即阻擋，不能當新帳本重建。global plan_ledgers index與預留在同一attached transaction更新；snapshot以單次read-only attached transaction驗binding/count/rows，不再RW/create重讀。獨立76項offline組合與原刪檔反例通過；這不保證使用者惡意同時刪除所有bootstrap痕跡或真斷電耐久。tests/test_chatgpt_plan.py、test_chatgpt_research.py為對應可重現案例，正式exact-head/Windows Gate仍待。

固定驗收另發現兩個UI接線缺口：MACD histogram數值為1倍但實際圖例未揭露倍數；PaperActionForm雖有risk說明但未實例化到主畫面。0.2.1用實際圖例與同一RiskLimits factory產生唯讀風控摘要修正，不新增無效可編輯參數，也不改實際風控門檻。tests/test_desktop_market_acceptance.py直接檢查MainWindow與非零histogram，避免只測未使用元件。

### 0.2.0 合併後正式產物核對（01:39 UTC）

mainfc2dfac，postmerge Windows38013204925 build/security/release及Quantlab38013204921通過；[0.2.0 Release](https://github.com/yostar77612/mark-auto/releases/tag/desktop-preview-38013204925-1)實際下載校验：EXE36,848,324bytes／SHA256be1c749e9fc83ede8c9a0e18d9be99a3c7e3104b4798dda6ccb1834f29471f29；kit72,511,372bytes／SHA2566aef9b3fe5a81913528fee9436a98c4e85edd3fa46a69f5e78a2f4dd058be3f3，ZIP8entries CRC PASS。build-manifest6,539bytes／SHA2567cf66be9406b842949cdf5501c2c28915a6baad532a46dcd4d911e818174e33d绑定fc2dfac。復原報告保留928舊檔/5資料sentinels/原設定，lifecycle設定另保留hash副本未刪。官方HTTP證據TAIEX6bars、TAIFEX19series38bars，皆EOD，非即時。

下一版baseline改固定為以上真0.2.0；初次633測試只有舊baseline測試仍期待0.1.2的metadata失敗，故依已實際下載的新版commit/size/digest更新固定fixture，並加強manifest與完整EXE digest斷言。品質門檻、未知檔保留及內容驗證沒有放寬，失敗紀錄保留；CI仍須在最終head重跑完整矩陣。

0.2.1首輪Windows CI（38014286480／38014286482）保留FAILED證據，未合併。四個根因分開處理：六個測試fixture用了SQLite connection context但未close，導致Windows刪除temporary時WinError32；改為closing＋原transaction，另保留connection物件測production成功/錯誤路徑明確close，沒有用GC/延遲/忽略cleanup掩蓋。DACL測試把SDDL縮寫LA直接和full SID文字比較；改讀原binaryACE並EqualSid，同時仍要求protected、單一allowACE、full access，另加異主體/異domain RID500反例，不允許泛用LA例外。deadline合成測試原只patch POSIX killpg，現分別測Linux killpg與Windows terminate分支，保留join/close/unknown-error全部斷言；native JobObject測試獨立。唯一production修正是build-manifest輸入路徑統一POSIX字元，原Windows反斜線key令跨平台雜湊查核失敗；既有kit/PowerShell讀取兼容兩種格式。92focused tests85PASS7native/tool skip，原完整633Linux結果保留，最終headWindows必須重驗。


0.2.1第二輪exact-head `7dc3536f`／本地`797f3cd`，Quantlab `38014802083`七jobs與Windows `38014802079` build/security全部通過：635測試624PASS11適用profile skip，原生DPAPI/DACL/refresh-lock、frozen crypto、安裝/升級/中斷復原Gate通過。這是Windows Server runner，非clean Win10/11。release因PR不是main正常skipped。

合併前新增offline反例實際重現release-blocking缺口：同bootstrap但不同OAuth registration，A預留未知請求後B仍status ready且能預留。來源 `desktop_chatgpt_provider.py` registration-keyed account lookup；不能假定issuer/client/subject跨registration必然代表相同人，也不能因此允許重試不確定呼叫。PR4保持未合併，修復方向為本安裝跨registration的active/unknown/paused屏障及既有ledger完整性確認，保留各自receipt/身分。新增反例與並行/明確解除已知pause驗收先固定，修復後重新跑exact-head Gate。沒有真正授權、token或網路推論。

獨立反例再確認兩個同源缺口：A已完成但其預期ledger遺失／毀損／回退時，B仍可當ready；較晚返回的model catalog已知quota錯誤能覆蓋先前未知推論狀態，使人工解除pause後誤允許新call。另standalone模型發現原未保存新觀察到的quota/auth pause。修復保持最小同一provider邊界：以全域交易內有界索引驗全部已登記ledger、receipt推導不可清除未知屏障、已知錯誤不得降低未知狀態、共用已知pause持久化。各registration身分和收據仍隔離，不查email或假定subject跨client相等。正式採用仍以最後來源的獨立反例／完整CI為準，原PASS不覆蓋後續修改。

02:11 UTC修復來源凍結：provider SHA256 `96d8c73b52c8cf337e1837ee0cb625cc0f5367e140b3cce595141d86cbdaffdb`、testplan `5a23e18746a2428883acd57d8a2d79a9e6ae107e8f2f1d58767463c7a6b7509b`。獨立10項反例、106相關回歸、35受支援auth測試通過，無剩餘範圍內阻擋；初始錯用非固定依賴環境的失敗另外保留。根目錄完整644測試629PASS15原生Windows/PowerShell不適用skip（85.155s），quality＋全可達Git歷史掃描0finding。新版exact-head Windows/PR Gate仍必須重新通過後才可合併；這些本地證據不是實際官方帳戶驗證。


## 0.2.2 一般操作與行情缺口補验

已確認的三個實際產品缺口：`desktop_market.py`沒有TX/MXF原生分鐘檔入口；`desktop_forms.BacktestForm`缺 `instrument_expiries`正常輸入，導致真13,680bar資料未跑即被核心正確拒絕；`desktop_ui.py:ui_paper_replay`忽略typed margin policy，固定100000，而正常120000設定在第一筆計畫被Paper核心拒絕。前兩個不是資料不存在，後者也不是應降低風控。

修復沿用現有市場bar/聚合與JobManager，新增bounded `quantlab/market_history.py`；table型別化到期設定；既有`PaperReplay`增加明示effective-datedschedule模式並從已鎖定broker取得trade_date政策。相同replay路径對不相容旧binding保留檔案、拒絕，不能改檔或重送。獨立95項Paper驗證含原缺陷cursor61失敗/保留pendingplan／原bytes不變／無替換ledger，與所有中斷重啟不重複下單。這些為simulationfixture，不是真券商驗證。

行情審查實際重現cache重新載入接受非法volume／長度、相同source吞入tamperedcache、並行quota競態、unknown檔忽略、鎖初始化/cleanup競態等，皆修正並保留原反例。64MiB輸入、百萬row、120秒、16MiBnormalizedcache與entry/combinedbytes雙quota；OS鎖內admission、immutable source/policyhash及hardlink發布、不覆蓋lastgood。CP950/UTF8九欄CSV與comma-delimitedRPT，未知fixedwidth拒絕；必須明示datedsession，不複製TMFcalendar到其他商品。來源policyURL為參考，不等於已認證。

原始privateCSV/RPT各677441rows/34363020bytes，SHA2566807f4c3b7f977cb7e5109b1135fe69bbfe18d7c6b71a445e6576bb6be6163a8，獨立各重現TX/MTX/TMF202610各300min共900bars，24商品周期GUI組合；outright量與含spread官方日量差保留說明。研究資料品質完全不放寬；market import仍history/unverified，不自動成為研究eligible。獨立159項市場組合通過，nativeWindows仍待本版Gate。

到期表單獨立九項與普通GUI真資料training-only重播兩次通過，5700bars結果hash81d5bf95bd100acd6ad4922f22da78bcf0b841d1e145ee4b48de2f249e7eae8b對同版同設定reference一致；沒有model/network/OOS/holdout呼叫。原dataset/calendar/expiry證據不變。不以此聲稱策略獲利、日期未來不會被交易所修訂或Windowsclient已驗證。

另重新核對需求確認：現有`research._campaign_config`只接受一次train/validation/oos/holdout，`purge_bars`不構成Walk-forward。這是尚待補齊的工程驗收項，不得列外部授權阻塞或宣稱全研究規範已滿。下一獨立模組先做預宣告固定built-in候選池的真rolling/expanding驗證，不假裝adaptiveAI或允許來歷不明AI候選。原百分比是既有清單計分，不覆蓋此次完整需求重驗發現的缺口。


### 02:36 UTC發布與分數核對

0.2.1 [Release](https://github.com/yostar77612/mark-auto/releases/tag/desktop-preview-38016622951-1)已實際下載核對：EXE41,583,381bytes／SHA256cce3f6242068affa91ab5c242f6ac655bbb59c677e4abda8b85065b97e48e0b1；clean-kit77,401,239bytes／SHA256850e2157d8b6652bc5d269bcd6dc76eba88f0ec7f81c29a75bc7e5b5a91768d4，8entriesCRC PASS；manifest7,247bytes／SHA2564c6c6b0a0ddff170c5394b7b04f03f3575c29b54087c9e042a60c3fb38bc5639綁main2ed1e3e。PostmergeWindows38016622951三jobs與Quantlab38016622996七jobsPASS。獨立重核全部8下載asset及56source inputs，Windows CRLF hash差與Git LF的確切轉換相符，沒有假定hash相同。更新復原保留929舊檔、5sentinel、真設定與lifecycle副本。Server單次啟動1.0279063s/RSS103309312bytes，非clientSLO。

M3完整15點可驗證，新增40/100，原170/200保留，已記錄總210/300＝70%，剩30%。M2/M4仍待候選0.2.2完整Gate，TAIEX分線能力/來源權限未解，M6真授權、M7cleanDPI仍未滿。重新比對使用者原文另確認ProfitFactor/Sharpe實作與停損/停利/成本參考線接線待補，連同Walk-forward列工程工作，不能拿既有窄項分數掩蓋。不得用新權重或移除需求美化百分比。

0.2.2沿用上述真正已發布0.2.1baseline，hash及測試固定fixture依實際下載更新。曾不必要修改recovery腳本舊default導致一項相容性測試失敗，已還原原default而非改門檻；工作流/kit仍明示0.2.1。後續40packaging測試36PASS4PowerShellskip，失敗log保留。另Qt對話框exec被原AST dynamic-call Gate同名拒絕，改用Qt正式非同步open/accepted/finished流程，加重複開啟／取消／关闭期间不啟動工作檢查，54相關測試PASS，原Gate不改，沒有改名或getattr隱藏呼叫。


### 2026-10-10 02:52 UTC：0.2.2 首輪 CI 與 TAIEX 分線權限

PR #5 的 acd2bfee（與本地 43811fa 相同 tree）首輪未通過，未合併、未發布。
- Windows run 38017986367 / job 114112443026：725 項，1 failure、1 error、12 skips。原生完整套件揭露 `tests/test_desktop_market_smoke.py:23` 未指定 UTF-8，在 CP1252 讀取新增中文字串時失敗；改為明示 UTF-8，原斷言不變。
- 同一 job 的 `test_paper_replay_policy.TypedReplayWorkerTests.test_typed_120000_normal_worker_and_repeat_are_safe` 在原 30 秒工作預算內未完成。Linux 相同 960 bars 測試 8.105 秒通過，cProfile 指向每 bar 重讀重建整份 broker journal（980 snapshots、21,136 reductions）及空計畫的 1,920 次 plan/cursor 寫入。正在做局部優化與中斷／篡改回歸，不延長門檻、不刪測試、不減少 fixture。
- Quantlab run 38017986330 的 core/UI jobs 缺少 Qt，新增 GUI 測試模組無法匯入。工作流將安裝同版 PySide6 Essentials / shiboken6 6.12.0 再跑完整套件，不把 import failure 改成跳過。Windows 正式發行仍使用原 hash-pinned 完整 runtime lock 與 native preflight。依賴、安全與完整 Git 歷史靜態 Gate 首輪通過，不代表整體 Gate 通過。

TAIEX 官方五秒指數來源存在，但免費自動下載／再利用權限尚未取得可核實依據，狀態為 EXTERNAL BLOCKED，不串接自動輪詢。
- 實際單次官方 `MI_5MINS_INDEX` 2026-10-08 回應為 3,241 rows / 39 columns，含時間與指數，無成交量；五秒取樣不是交易所原生分鐘 OHLC。09:00:00 是前日收盤 49,806.37，09:00:05 才與當日開盤 49,783.06 相符，不能把前日值算進當日最高價。
- [證交所使用條款](https://www.twse.com.tw/zh/terms/use.html) 第 6、8 節對自動下載另有限制與例外；[政府資料集 11755](https://data.gov.tw/dataset/11755) 是每日 OHLC，不能將其授權套用到五秒來源。[官方 OpenAPI](https://openapi.twse.com.tw/v1/swagger.json) 未列該五秒 endpoint。
- 確認限制後停止後續 payload 下載，僅查條款／目錄。未以 MIS 瀏覽頁或其他端點繞過限制，未將原始 payload 或衍生 bars 放進產品、Git 或 Release。未宣稱該來源一定違法；結論限於本次無法證實所需自動使用權限。


Paper 局部修復已經獨立套用並进入完整回歸：`paper._restore` 每次交易仍在鎖內逐列讀取 seq / identity / operation / payload / state_hash 與 materialized snapshot；只有所有 bytes 與上次已驗證內容完全一致才复用驗證結果，回傳重新解析的 detached state。快取限制為 1 MiB serialized proof，大於限制回到原 streaming replay；儲存不確定標記在兩條路徑後皆執行。外部 kill／restart／篡改／截斷與 transaction rollback 均加入回歸。此機制沒有外部 monotonic anchor，不能識別所有自洽整庫回滾，不作 anti-rollback 新保證。

空決策與 consumed cursor 合成一次 FULL-sync transaction；不能在重啟後重新解讀已滿足的 target，舊版持久化 `[]` 也按既有決策消耗。量測相同 960 bars、17 orders、5 fills、31 journal events：Linux replay 4.254 秒 → 0.517 秒，原 typed Qt/spawn-worker 案例 8.105 秒 → 3.899 秒；原 30 秒上限不改。這是 Linux 量測，Windows 仍須 exact-head CI 實測，不能先報通過。

修復後完整 Linux suite：738 項，723 PASS、15 項既有 Windows／PowerShell 平台檢查未執行，105.539 秒；靜態／完整 Git 歷史 Gate 0 findings。原 960-bar／30 秒 GUI case 通過，Windows exact-head 驗證仍待新 CI，不以 Linux 結果替代。


CI 環境補齊另保留兩次失敗：run 38019029420 因 shell 參數 `--only-binary=:all:` 未作 YAML 字串引用而解析失敗，已引用並本地解析檢查；後續 head 716763a / Linux job 114116001456 在 Qt wheel 安裝後缺 `libEGL.so.1`。現明確安裝 Ubuntu 官方 libegl1 / libopengl0 / libxkbcommon0 並設定 offscreen，保留完整測試，不把 GUI 缺環境改成跳過。Windows 正式產品仍使用自己的原生 Qt 環境與鎖檔；Linux headless 測試不作 Windows 相容性替代。


### 2026-10-10 03:18 UTC：原生結果差異與下一次診斷

head 716763a 的 Windows Server 2022 / Python 3.13.16 run 38019136760 已通過 build、安全、738 項原生測試（726 PASS、12 profile skips）、frozen history smoke、安裝與真正 0.2.1 升級／中斷復原。此結果不能替代尚失敗的完整矩陣：Windows-latest / Python 3.11 的相同 30 秒 replay case 仍逾時；Python 3.12 另有原本 10 秒 process-death golden 逾時。未合併，未發布 0.2.2。

增加僅在 Windows CI 失敗後執行的 `tools/diagnose_paper_replay.py`，以同一 960-bar／120000 typed UI 與真 spawn worker 觀測 SQLite connect／transaction／commit／close、restore、啟動及完整工作時間，並測量原 before/after-event-commit fixture。它不改 SQL、sync、原 30 秒／10 秒 Gate；獨立 180 秒上限僅用於取得診斷，有清理保留與子樹停止，輸出明示非驗收。失敗的原 CI 不因診斷成功變成 PASS。先取得 Windows 時間分布，再決定 scoped connection reuse 是否必要；尚未改 journaling mode 或持久化語意。


### 2026-10-10 03:34 UTC：原生逾時已定位，完整 Gate 仍未通過

同一 PR #5 head `71f8feb73f4f73d09f9ffe14d1f8e6970ab63ecc` 的 Windows Server 2022 run 38020197303 / build 114119289481 再次通過 build、安全、安裝、真 0.2.1 升級、移除保存及中斷復原。Quantlab Windows 3.11 通過，但 Windows 3.12 job 114119289510 仍未達原 30 秒 Paper 門檻，不合併、不發布。Linux Qt 系統函式庫問題已解除，完整 source smoke 接著揭露四個 auth runtime 缺失；工作流補齊既有固定 PyJWT/cryptography/cffi/pycparser 版本，先做原本離線驗證，再跑完整套件，不跳過失敗。

Windows Server 2025 / Python 3.12.10 / SQLite 3.49.1 的相同 960-bar 診斷：worker 29.718 秒，其中 960 次 cursor commit 25.713 秒；所有 replay connection 0.376 秒、broker connection 0.253 秒，故不能把重用連線當主要解法。兩個原 process-death fixture 本次 0.281/0.297 秒，皆 exit 73，先前 10 秒逾時未重現，門檻保持不變。診斷有界且完成 worker 清理，不取代原測試 FAILED。

下一步先在原生 runner 的 disposable 檔案測 DELETE/TRUNCATE/PERSIST + FULL，保留每個既有耐久邊界。尚未改產品 journal mode。[SQLite 官方 WAL 說明](https://sqlite.org/wal.html#walreset)與[3.51.3 修復說明](https://sqlite.org/releaselog/3_51_3.html)指出現有 3.49.1 屬 WAL-reset 問題版本範圍；不得為效能直接開啟未審核 WAL。若採 rollback-journal 模式改善，仍須真實 process-death、備份還原、legacy pending plan、外部 kill 與完整 native 原門檻。


### Smoke 驗收寫入使用者狀態：已重現、修復中

獨立反例在隔離的既有模擬帳戶副本執行原 `desktop.py --smoke-test`：exit 0/status passed，但 `state-v1/desktop_safety.json` 與 `state-v1/paper.sqlite3` bytes 改變，kill switch 變 true。原因為合成 worker 雖隔離，主視窗仍先用正式 workspace 啟動並執行 `freeze_paper`。只有 settings 檔不變的既有測試不足以涵蓋此缺陷。這是當前 release blocker；正常啟動的安全停止仍必要，不可刪除。修復須在主視窗/lock/guard 建立前隔離整個 smoke workspace，原設定只讀快照，並以成功與注入失敗測試證明正式目錄、broker、safety、settings、recovery 記錄皆不變。保留原安裝路徑檢查語意，明示 report 的被檢查位置與真正暫存執行位置；最終 exact-head 安裝／升級／復原 Gate 需重跑。


### 03:53 UTC：Smoke 只讀隔離與 CI 固定依賴目標修復

主視窗 smoke startup 現在先建立暫存 root，原設定 workspace 僅透過 `WorkspaceLocator.load(probe=False)` 驗證後讀取；正常 startup 的探測、復原、mutex、停止／對帳規則不變。report.data_dir 保留被檢查設定位置，smoke_data_dir 明示真正暫存執行位置。七項來源測試覆蓋 default/redirected/不存在 root、broker/safety/settings/recovery 全目錄 bytes/names 與 transient write audit hook；Linux PASS。Windows來源測試只把 known-folder discovery 指向測試fixture，native mutex/Qt/spawn 保留真實，非 clean-client 或 known-folder API 的替代驗證。

新增依賴後，原 matrix 的 Win3.11/3.12/Linux3.11 被既有嚴格來源驗證以 unsupported_dependency_target 拒絕（run38021395788），並未執行套件或取得 native benchmark；Linux3.12和UI完整套件已通過。修復明示新增這三個既有CI目標，不刪矩陣／測試。原 Win3.13/Linux3.12 target records 與正式 Windows lock 不變；從官方 PyPI 實際下載九個不同wheel逐一驗hash。共享manifest解析留在已hash綁定的 provider.py，CI-only installer採binary-only、require-hashes、isolated PyPI、force-reinstall並逐一核對pip report的closure/version/digest。真Linux3.12 fresh及已有套件重裝、原OpenSSL4.0.3離線驗證通過；新增native目標仍待CI。

Root完整759 tests：744PASS、15既有Windows/PowerShell平台skip，103.709秒；quality及全Git歷史0finding。四個auth runtime套件的獨立供應鏈audit無已知漏洞；bootstrap pip工具自身的掃描發現另記錄，不能用runtime結果認證工具。原30秒Paper與10秒process-death門檻不變。仍待原生磁碟模式量測、最終timer/cleanup錯誤terminal-proof與exact-head完整Gate，未合併。
