Native Qt dependency notices

Read manifest.json for component -> license text mappings, exact official source URLs, versions, copyright notices and SHA-256 values. Identical raw license texts share one texts/<sha256>.txt entry. All text inputs are preserved byte-for-byte; NOTICE captures identify their source and include upstream notices.

Qt's source attribution metadata covers both always-built and optional features. This is a conservative Windows-module notice set, not a claim that every listed optional component is present. Platform-only, test/tool/example-only and excluded Qt module dependencies are not added as application dependencies.

This product includes software developed by the FreeType Project (https://www.freetype.org/). FreeType is provided under the FreeType Project License option, with its required acknowledgments and copyright notices.

The Public Suffix List data is available under MPL-2.0; its complete source is included in the pinned Qt source release archive beside the installer and the component's versioned source-directory link. No rights in that source are restricted by MarkAuto's Apache-2.0 license.

These third-party works retain their own terms. Their presence does not relicense MarkAuto or supply a Microsoft runtime redistribution grant.
